# Vector Image Search

A Drupal module for finding similar images in your Media Library using vector-based image comparison techniques.

## Features

* Search for visually similar images in your Media Library
* Upload an image or select one from your Media Library to use as a search query
* Combines three complementary image comparison techniques:
  * Perceptual Hash (pHash) - for layout and structure similarity
  * Color Histogram Analysis - for color distribution similarity
  * Edge Detection - for shape and contour similarity
* Adjust feature weights to emphasize different aspects of similarity
* Set similarity threshold to filter results
* Paginated results with visual similarity indicators
* Built for Drupal 9.4+ and 10.x

## Requirements

* Drupal 9.4+ or Drupal 10.x
* PHP 7.4+ with GD extension enabled
* Media module enabled and configured with at least one image media type

## Installation

1. Download and extract the module to your site's modules directory
2. Enable the module via Drush: `drush en vectorimg`
   Or through the Drupal admin interface: Extend > Vector Image Search > Install
3. Grant appropriate permissions to roles that should use the module

## Configuration

1. Go to Configuration > Media > Vector Image Search
2. Set the default parameters:
   * Results per page
   * Default similarity threshold
   * Feature weights (color, edge, perceptual hash)
   * Indexing options

## Usage

1. Go to Content > Vector Image Search
2. Choose an image source:
   * Upload a new image
   * Select an existing image from your Media Library
3. Adjust search parameters if needed
4. Click "Search for similar images"
5. Browse through the paginated results showing similar images with similarity scores

## Technical Details

This module uses pure PHP implementations of image processing algorithms without requiring third-party libraries or services. It works entirely within your Drupal installation, with no external dependencies.

* **Perceptual Hashing**: Creates a fingerprint of image appearance that is robust to minor modifications
* **Color Histogram Analysis**: Compares color distributions independent of layout
* **Edge Detection**: Examines shapes and contours using Sobel operator

## Credits

Developed by [Your Name/Organization]

## License

This project is licensed under the GNU General Public License v2.0.