<?php

namespace Drupal\vectorimg\ImageProcessor;

/**
 * Provides perceptual hash functionality for image comparison.
 */
class PerceptualHash {

  /**
   * Generates a perceptual hash for an image.
   *
   * @param resource $image
   *   GD image resource.
   * @param int $size
   *   Size of the hash (default: 8 resulting in 64-bit hash).
   *
   * @return string
   *   Hexadecimal representation of the perceptual hash.
   */
  public function generateHash($image, $size = 8) {
    // Resize to a small square (e.g., 8x8 for a 64-bit hash).
    $small_img = imagecreatetruecolor($size, $size);
    $width = imagesx($image);
    $height = imagesy($image);
    
    // Resize with anti-aliasing to grayscale.
    imagecopyresampled($small_img, $image, 0, 0, 0, 0, $size, $size, $width, $height);
    
    // Convert to grayscale and collect pixel values.
    $pixels = [];
    for ($y = 0; $y < $size; $y++) {
      for ($x = 0; $x < $size; $x++) {
        $rgb = imagecolorat($small_img, $x, $y);
        $r = ($rgb >> 16) & 0xFF;
        $g = ($rgb >> 8) & 0xFF;
        $b = $rgb & 0xFF;
        
        // Simple grayscale conversion.
        $gray = intval(($r + $g + $b) / 3);
        $pixels[] = $gray;
      }
    }
    
    // Calculate the average value.
    $avg = array_sum($pixels) / count($pixels);
    
    // Create the hash by comparing each pixel to the average.
    $hash = '';
    $decimal_hash = 0;
    
    for ($i = 0; $i < count($pixels); $i++) {
      $bit = ($pixels[$i] >= $avg) ? 1 : 0;
      $hash .= $bit;
      
      // Build decimal value.
      $decimal_hash = ($decimal_hash << 1) | $bit;
      
      // Convert to hex string every 4 bits.
      if (($i + 1) % 4 == 0) {
        $hash_part = dechex($decimal_hash);
        $hash_hex .= $hash_part;
        $decimal_hash = 0;
      }
    }
    
    imagedestroy($small_img);
    
    return $hash_hex;
  }

  /**
   * Computes the Hamming distance between two hashes.
   *
   * @param string $hash1
   *   First hash in hexadecimal.
   * @param string $hash2
   *   Second hash in hexadecimal.
   *
   * @return int
   *   The number of differing bits (Hamming distance).
   */
  public function hammingDistance($hash1, $hash2) {
    // Convert hex string to binary.
    $bin1 = $this->hexToBin($hash1);
    $bin2 = $this->hexToBin($hash2);
    
    // Count differing bits.
    $distance = 0;
    $length = min(strlen($bin1), strlen($bin2));
    
    for ($i = 0; $i < $length; $i++) {
      if ($bin1[$i] !== $bin2[$i]) {
        $distance++;
      }
    }
    
    return $distance;
  }

  /**
   * Calculates similarity between two perceptual hashes (0-1).
   *
   * @param string $hash1
   *   First hash.
   * @param string $hash2
   *   Second hash.
   *
   * @return float
   *   Similarity score (1 = identical, 0 = completely different).
   */
  public function calculateSimilarity($hash1, $hash2) {
    $max_distance = strlen($hash1) * 4; // Maximum bits in hash.
    $distance = $this->hammingDistance($hash1, $hash2);
    
    // Convert distance to similarity (inversely proportional).
    $similarity = 1 - ($distance / $max_distance);
    
    return $similarity;
  }

  /**
   * Converts a hexadecimal string to a binary string.
   *
   * @param string $hex
   *   Hexadecimal string.
   *
   * @return string
   *   Binary representation as string of 0s and 1s.
   */
  protected function hexToBin($hex) {
    $bin = '';
    for ($i = 0; $i < strlen($hex); $i++) {
      $decimal = hexdec($hex[$i]);
      $binary = decbin($decimal);
      // Ensure 4 bits per hex character.
      $bin .= str_pad($binary, 4, '0', STR_PAD_LEFT);
    }
    return $bin;
  }

}