<?php

namespace Drupal\vectorimg\ImageProcessor;

use Drupal\Core\Config\ConfigFactoryInterface;

/**
 * Provides color histogram functionality for image comparison.
 */
class ColorHistogram {

  /**
   * The configuration factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * Constructs a ColorHistogram object.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The configuration factory.
   */
  public function __construct(ConfigFactoryInterface $config_factory) {
    $this->configFactory = $config_factory;
  }

  /**
   * Generates a color histogram for an image.
   *
   * @param resource $image
   *   GD image resource.
   *
   * @return array
   *   The color histogram.
   */
  public function generateHistogram($image) {
    $config = $this->configFactory->get('vectorimg.settings');
    $bin_count = $config->get('color_histogram_bins');
    
    // Default to 32 bins if not configured.
    if (empty($bin_count)) {
      $bin_count = 32;
    }
    
    $width = imagesx($image);
    $height = imagesy($image);
    $pixel_count = $width * $height;
    
    // Initialize histograms for each channel.
    $r_hist = array_fill(0, $bin_count, 0);
    $g_hist = array_fill(0, $bin_count, 0);
    $b_hist = array_fill(0, $bin_count, 0);
    
    // Build histogram.
    for ($y = 0; $y < $height; $y++) {
      for ($x = 0; $x < $width; $x++) {
        $rgb = imagecolorat($image, $x, $y);
        
        $r = ($rgb >> 16) & 0xFF;
        $g = ($rgb >> 8) & 0xFF;
        $b = $rgb & 0xFF;
        
        // Map color values to bins.
        $r_bin = floor($r * $bin_count / 256);
        $g_bin = floor($g * $bin_count / 256);
        $b_bin = floor($b * $bin_count / 256);
        
        // Increment bin counts.
        $r_hist[$r_bin]++;
        $g_hist[$g_bin]++;
        $b_hist[$b_bin]++;
      }
    }
    
    // Normalize histograms by pixel count.
    for ($i = 0; $i < $bin_count; $i++) {
      $r_hist[$i] /= $pixel_count;
      $g_hist[$i] /= $pixel_count;
      $b_hist[$i] /= $pixel_count;
    }
    
    return [
      'r' => $r_hist,
      'g' => $g_hist,
      'b' => $b_hist,
    ];
  }

  /**
   * Calculates similarity between two color histograms (0-1).
   *
   * @param array $hist1
   *   First histogram.
   * @param array $hist2
   *   Second histogram.
   *
   * @return float
   *   Similarity score (1 = identical, 0 = completely different).
   */
  public function calculateSimilarity(array $hist1, array $hist2) {
    // Histogram intersection distance.
    $r_similarity = $this->histogramIntersection($hist1['r'], $hist2['r']);
    $g_similarity = $this->histogramIntersection($hist1['g'], $hist2['g']);
    $b_similarity = $this->histogramIntersection($hist1['b'], $hist2['b']);
    
    // Average similarity across channels.
    $similarity = ($r_similarity + $g_similarity + $b_similarity) / 3;
    
    return $similarity;
  }

  /**
   * Calculates the intersection between two histograms.
   *
   * @param array $hist1
   *   First histogram.
   * @param array $hist2
   *   Second histogram.
   *
   * @return float
   *   Intersection value (0-1).
   */
  protected function histogramIntersection(array $hist1, array $hist2) {
    $intersection = 0;
    
    for ($i = 0; $i < min(count($hist1), count($hist2)); $i++) {
      $intersection += min($hist1[$i], $hist2[$i]);
    }
    
    return $intersection;
  }

}