<?php

namespace Drupal\vectorimg\ImageProcessor;

use Drupal\Core\Config\ConfigFactoryInterface;

/**
 * Provides color histogram functionality and analysis for image comparison.
 */
class ColorHistogram {

  /**
   * The configuration factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * Constructs a ColorHistogram object.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The configuration factory.
   */
  public function __construct(ConfigFactoryInterface $config_factory) {
    $this->configFactory = $config_factory;
  }

  /**
   * Generates a color histogram for an image.
   *
   * @param resource $image
   *   GD image resource.
   *
   * @return array
   *   The color histogram.
   */
  public function generateHistogram($image) {
    $config = $this->configFactory->get('vectorimg.settings');
    $bin_count = $config->get('color_histogram_bins');
    
    // Default to 32 bins if not configured.
    if (empty($bin_count)) {
      $bin_count = 32;
    }
    
    $width = imagesx($image);
    $height = imagesy($image);
    $pixel_count = $width * $height;
    
    // Initialize histograms for each channel.
    $r_hist = array_fill(0, $bin_count, 0);
    $g_hist = array_fill(0, $bin_count, 0);
    $b_hist = array_fill(0, $bin_count, 0);
    
    // Build histogram.
    for ($y = 0; $y < $height; $y++) {
      for ($x = 0; $x < $width; $x++) {
        $rgb = imagecolorat($image, $x, $y);
        
        $r = ($rgb >> 16) & 0xFF;
        $g = ($rgb >> 8) & 0xFF;
        $b = $rgb & 0xFF;
        
        // Map color values to bins.
        $r_bin = floor($r * $bin_count / 256);
        $g_bin = floor($g * $bin_count / 256);
        $b_bin = floor($b * $bin_count / 256);
        
        // Increment bin counts.
        $r_hist[$r_bin]++;
        $g_hist[$g_bin]++;
        $b_hist[$b_bin]++;
      }
    }
    
    // Normalize histograms by pixel count.
    for ($i = 0; $i < $bin_count; $i++) {
      $r_hist[$i] /= $pixel_count;
      $g_hist[$i] /= $pixel_count;
      $b_hist[$i] /= $pixel_count;
    }
    
    return [
      'r' => $r_hist,
      'g' => $g_hist,
      'b' => $b_hist,
    ];
  }

  /**
   * Calculates similarity between two color histograms (0-1).
   *
   * @param array $hist1
   *   First histogram.
   * @param array $hist2
   *   Second histogram.
   *
   * @return float
   *   Similarity score (1 = identical, 0 = completely different).
   */
  public function calculateSimilarity(array $hist1, array $hist2) {
    // Histogram intersection distance.
    $r_similarity = $this->histogramIntersection($hist1['r'], $hist2['r']);
    $g_similarity = $this->histogramIntersection($hist1['g'], $hist2['g']);
    $b_similarity = $this->histogramIntersection($hist1['b'], $hist2['b']);
    
    // Average similarity across channels.
    $similarity = ($r_similarity + $g_similarity + $b_similarity) / 3;
    
    return $similarity;
  }

  /**
   * Calculates the intersection between two histograms.
   *
   * @param array $hist1
   *   First histogram.
   * @param array $hist2
   *   Second histogram.
   *
   * @return float
   *   Intersection value (0-1).
   */
  protected function histogramIntersection(array $hist1, array $hist2) {
    $intersection = 0;
    
    for ($i = 0; $i < min(count($hist1), count($hist2)); $i++) {
      $intersection += min($hist1[$i], $hist2[$i]);
    }
    
    return $intersection;
  }

  /**
   * Extracts the dominant colors from an image.
   *
   * @param resource $image
   *   GD image resource.
   * @param int $max_colors
   *   Maximum number of dominant colors to extract (default: 5).
   *
   * @return array
   *   Array of dominant colors as RGB hex values.
   */
  public function extractDominantColors($image, $max_colors = 5) {
    $width = imagesx($image);
    $height = imagesy($image);
    
    // Sample the image (analyze every 4th pixel to save processing time).
    $sample_step = 4;
    $colors = [];
    
    for ($y = 0; $y < $height; $y += $sample_step) {
      for ($x = 0; $x < $width; $x += $sample_step) {
        $rgb = imagecolorat($image, $x, $y);
        
        // Skip fully transparent pixels.
        if (($rgb >> 24) & 0x7F === 127) {
          continue;
        }
        
        $r = ($rgb >> 16) & 0xFF;
        $g = ($rgb >> 8) & 0xFF;
        $b = $rgb & 0xFF;
        
        // Group similar colors by reducing precision.
        $r_quan = floor($r / 16) * 16;
        $g_quan = floor($g / 16) * 16;
        $b_quan = floor($b / 16) * 16;
        
        $color_key = sprintf('%02X%02X%02X', $r_quan, $g_quan, $b_quan);
        
        if (isset($colors[$color_key])) {
          $colors[$color_key]['count']++;
          
          // Refine average color.
          $colors[$color_key]['r'] = ($colors[$color_key]['r'] * ($colors[$color_key]['count'] - 1) + $r) / $colors[$color_key]['count'];
          $colors[$color_key]['g'] = ($colors[$color_key]['g'] * ($colors[$color_key]['count'] - 1) + $g) / $colors[$color_key]['count'];
          $colors[$color_key]['b'] = ($colors[$color_key]['b'] * ($colors[$color_key]['count'] - 1) + $b) / $colors[$color_key]['count'];
        }
        else {
          $colors[$color_key] = [
            'r' => $r,
            'g' => $g,
            'b' => $b,
            'count' => 1,
          ];
        }
      }
    }
    
    // Sort by frequency (most common first).
    uasort($colors, function ($a, $b) {
      return $b['count'] <=> $a['count'];
    });
    
    // Take top colors.
    $dominant_colors = [];
    $count = 0;
    
    foreach ($colors as $color) {
      $hex = sprintf('#%02X%02X%02X', 
        round($color['r']), 
        round($color['g']), 
        round($color['b'])
      );
      
      $dominant_colors[] = $hex;
      $count++;
      
      if ($count >= $max_colors) {
        break;
      }
    }
    
    return $dominant_colors;
  }
  
  /**
   * Generates a comma-separated string of dominant colors.
   *
   * @param resource $image
   *   GD image resource.
   *
   * @return string
   *   Comma-separated list of dominant colors in hex format.
   */
  public function getDominantColorsString($image) {
    $colors = $this->extractDominantColors($image);
    return implode(',', $colors);
  }
  
  /**
   * Calculates the average color of an image.
   *
   * @param resource $image
   *   GD image resource.
   *
   * @return string
   *   Average color as hex string (e.g., "#FF5500").
   */
  public function getAverageColor($image) {
    $width = imagesx($image);
    $height = imagesy($image);
    
    $r_total = 0;
    $g_total = 0;
    $b_total = 0;
    $pixel_count = 0;
    
    // Sample the image (for better performance).
    $sample_step = 4;
    
    for ($y = 0; $y < $height; $y += $sample_step) {
      for ($x = 0; $x < $width; $x += $sample_step) {
        $rgb = imagecolorat($image, $x, $y);
        
        // Skip fully transparent pixels.
        if (($rgb >> 24) & 0x7F === 127) {
          continue;
        }
        
        $r = ($rgb >> 16) & 0xFF;
        $g = ($rgb >> 8) & 0xFF;
        $b = $rgb & 0xFF;
        
        $r_total += $r;
        $g_total += $g;
        $b_total += $b;
        $pixel_count++;
      }
    }
    
    if ($pixel_count > 0) {
      $r_avg = round($r_total / $pixel_count);
      $g_avg = round($g_total / $pixel_count);
      $b_avg = round($b_total / $pixel_count);
      
      return sprintf('#%02X%02X%02X', $r_avg, $g_avg, $b_avg);
    }
    
    // Default to black if no valid pixels (shouldn't happen).
    return '#000000';
  }
  
  /**
   * Calculates the aspect ratio of an image.
   *
   * @param resource $image
   *   GD image resource.
   *
   * @return float
   *   Width/height ratio.
   */
  public function getAspectRatio($image) {
    $width = imagesx($image);
    $height = imagesy($image);
    
    if ($height == 0) {
      return 1.0; // Avoid division by zero.
    }
    
    return $width / $height;
  }

}