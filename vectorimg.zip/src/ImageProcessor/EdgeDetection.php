<?php

namespace Drupal\vectorimg\ImageProcessor;

/**
 * Provides edge detection functionality for image comparison.
 */
class EdgeDetection {

  /**
   * Extracts edge features from an image.
   *
   * @param resource $image
   *   GD image resource.
   *
   * @return array
   *   The edge features vector.
   */
  public function extractEdgeFeatures($image) {
    $width = imagesx($image);
    $height = imagesy($image);
    
    // Create a grayscale copy for edge detection.
    $grayscale = imagecreatetruecolor($width, $height);
    
    // Convert to grayscale.
    for ($y = 0; $y < $height; $y++) {
      for ($x = 0; $x < $width; $x++) {
        $rgb = imagecolorat($image, $x, $y);
        $r = ($rgb >> 16) & 0xFF;
        $g = ($rgb >> 8) & 0xFF;
        $b = $rgb & 0xFF;
        
        // Standard grayscale conversion.
        $gray = (int) (0.299 * $r + 0.587 * $g + 0.114 * $b);
        $gray_color = imagecolorallocate($grayscale, $gray, $gray, $gray);
        imagesetpixel($grayscale, $x, $y, $gray_color);
      }
    }
    
    // Apply Sobel edge detection.
    $edges = $this->sobelOperator($grayscale);
    
    // Divide image into a grid and calculate edge density in each cell.
    $grid_size = 8; // 8x8 grid
    $cell_width = floor($width / $grid_size);
    $cell_height = floor($height / $grid_size);
    
    $edge_features = [];
    
    for ($grid_y = 0; $grid_y < $grid_size; $grid_y++) {
      for ($grid_x = 0; $grid_x < $grid_size; $grid_x++) {
        $start_x = $grid_x * $cell_width;
        $start_y = $grid_y * $cell_height;
        
        // Count edge pixels in this cell.
        $edge_count = 0;
        $total_pixels = 0;
        
        for ($y = $start_y; $y < min($start_y + $cell_height, $height); $y++) {
          for ($x = $start_x; $x < min($start_x + $cell_width, $width); $x++) {
            if (isset($edges[$y][$x]) && $edges[$y][$x] > 0) {
              $edge_count++;
            }
            $total_pixels++;
          }
        }
        
        // Calculate edge density for this cell.
        $density = ($total_pixels > 0) ? $edge_count / $total_pixels : 0;
        $edge_features[] = $density;
      }
    }
    
    // Clean up.
    imagedestroy($grayscale);
    
    return $edge_features;
  }

  /**
   * Applies Sobel operator for edge detection.
   *
   * @param resource $image
   *   GD grayscale image.
   *
   * @return array
   *   2D array of edge magnitude values.
   */
  protected function sobelOperator($image) {
    $width = imagesx($image);
    $height = imagesy($image);
    
    // Sobel kernels for X and Y gradients.
    $kernel_x = [
      [-1, 0, 1],
      [-2, 0, 2],
      [-1, 0, 1],
    ];
    
    $kernel_y = [
      [-1, -2, -1],
      [0, 0, 0],
      [1, 2, 1],
    ];
    
    // Initialize gradient array.
    $edges = [];
    
    // Apply Sobel operator.
    for ($y = 1; $y < $height - 1; $y++) {
      $edges[$y] = [];
      
      for ($x = 1; $x < $width - 1; $x++) {
        $gx = 0;
        $gy = 0;
        
        // Apply kernels to 3x3 neighborhood.
        for ($ky = -1; $ky <= 1; $ky++) {
          for ($kx = -1; $kx <= 1; $kx++) {
            $rgb = imagecolorat($image, $x + $kx, $y + $ky);
            $r = ($rgb >> 16) & 0xFF;
            $g = ($rgb >> 8) & 0xFF;
            $b = $rgb & 0xFF;
            
            // Use red channel only (since image is grayscale, all channels should be equal).
            $intensity = $r;
            
            $gx += $intensity * $kernel_x[$ky + 1][$kx + 1];
            $gy += $intensity * $kernel_y[$ky + 1][$kx + 1];
          }
        }
        
        // Calculate gradient magnitude.
        $magnitude = sqrt($gx * $gx + $gy * $gy);
        
        // Normalize to 0-255.
        $magnitude = min(255, max(0, $magnitude));
        
        // Apply threshold to reduce noise.
        $edges[$y][$x] = ($magnitude > 30) ? $magnitude : 0;
      }
    }
    
    return $edges;
  }

  /**
   * Calculates similarity between two edge feature vectors (0-1).
   *
   * @param array $edges1
   *   First edge feature vector.
   * @param array $edges2
   *   Second edge feature vector.
   *
   * @return float
   *   Similarity score (1 = identical, 0 = completely different).
   */
  public function calculateSimilarity(array $edges1, array $edges2) {
    $distance = 0;
    $count = min(count($edges1), count($edges2));
    
    if ($count == 0) {
      return 0;
    }
    
    // Calculate Euclidean distance.
    for ($i = 0; $i < $count; $i++) {
      $diff = $edges1[$i] - $edges2[$i];
      $distance += $diff * $diff;
    }
    
    $distance = sqrt($distance);
    
    // Convert distance to similarity (inversely proportional).
    // Normalize based on maximum possible distance.
    $max_distance = sqrt($count); // Maximum possible Euclidean distance when values are in range 0-1.
    $similarity = 1 - ($distance / $max_distance);
    
    return max(0, min(1, $similarity));
  }

}