<?php

namespace Drupal\vectorimg\ImageProcessor;

/**
 * Provides vector comparison functionality for image similarity calculation.
 */
class VectorComparison {

  /**
   * The perceptual hash processor.
   *
   * @var \Drupal\vectorimg\ImageProcessor\PerceptualHash
   */
  protected $perceptualHash;

  /**
   * The color histogram processor.
   *
   * @var \Drupal\vectorimg\ImageProcessor\ColorHistogram
   */
  protected $colorHistogram;

  /**
   * The edge detection processor.
   *
   * @var \Drupal\vectorimg\ImageProcessor\EdgeDetection
   */
  protected $edgeDetection;

  /**
   * Constructs a VectorComparison object.
   *
   * @param \Drupal\vectorimg\ImageProcessor\PerceptualHash $perceptual_hash
   *   The perceptual hash processor.
   * @param \Drupal\vectorimg\ImageProcessor\ColorHistogram $color_histogram
   *   The color histogram processor.
   * @param \Drupal\vectorimg\ImageProcessor\EdgeDetection $edge_detection
   *   The edge detection processor.
   */
  public function __construct(
    PerceptualHash $perceptual_hash,
    ColorHistogram $color_histogram,
    EdgeDetection $edge_detection
  ) {
    $this->perceptualHash = $perceptual_hash;
    $this->colorHistogram = $color_histogram;
    $this->edgeDetection = $edge_detection;
  }

  /**
   * Calculates the overall similarity between two sets of image features.
   *
   * @param array $features1
   *   First set of image features.
   * @param array $features2
   *   Second set of image features.
   * @param array $weights
   *   Weights for each feature type (must sum to 1).
   *
   * @return float
   *   Overall similarity score (0-1).
   */
  public function calculateSimilarity(array $features1, array $features2, array $weights) {
    // Ensure weights are normalized.
    $total_weight = array_sum($weights);
    if ($total_weight <= 0) {
      // Default to equal weights if invalid.
      $weights = [
        'color' => 0.33,
        'edge' => 0.33,
        'phash' => 0.34,
      ];
    }
    else {
      foreach ($weights as $key => $weight) {
        $weights[$key] = $weight / $total_weight;
      }
    }
    
    // Calculate perceptual hash similarity.
    $phash_similarity = $this->perceptualHash->calculateSimilarity(
      $features1['phash'],
      $features2['phash']
    );
    
    // Calculate color histogram similarity.
    $color_similarity = $this->colorHistogram->calculateSimilarity(
      unserialize($features1['color_histogram']),
      unserialize($features2['color_histogram'])
    );
    
    // Calculate edge feature similarity.
    $edge_similarity = $this->edgeDetection->calculateSimilarity(
      unserialize($features1['edge_features']),
      unserialize($features2['edge_features'])
    );
    
    // Calculate weighted average similarity.
    $overall_similarity = 
      $weights['phash'] * $phash_similarity +
      $weights['color'] * $color_similarity +
      $weights['edge'] * $edge_similarity;
    
    return $overall_similarity;
  }

  /**
   * Ranks a set of images by similarity to a query image.
   *
   * @param array $query_features
   *   The features of the query image.
   * @param array $candidates
   *   Array of candidate images with their features.
   * @param array $weights
   *   The feature weights to use.
   * @param float $threshold
   *   Minimum similarity threshold (0-1).
   *
   * @return array
   *   Ranked list of similar images with similarity scores.
   */
  public function rankBySimilarity(array $query_features, array $candidates, array $weights, $threshold = 0) {
    $results = [];
    
    foreach ($candidates as $candidate) {
      $similarity = $this->calculateSimilarity(
        $query_features,
        $candidate['features'],
        $weights
      );
      
      if ($similarity >= $threshold) {
        $results[] = [
          'id' => $candidate['id'],
          'similarity' => $similarity,
        ];
      }
    }
    
    // Sort by similarity (descending).
    usort($results, function ($a, $b) {
      return $b['similarity'] <=> $a['similarity'];
    });
    
    return $results;
  }

}