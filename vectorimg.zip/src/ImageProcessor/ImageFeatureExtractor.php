<?php

namespace Drupal\vectorimg\ImageProcessor;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Image\ImageFactory;

/**
 * Extracts features from images for vector-based image search.
 */
class ImageFeatureExtractor {

  /**
   * The configuration factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The logger factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * The file system service.
   *
   * @var \Drupal\Core\File\FileSystemInterface
   */
  protected $fileSystem;

  /**
   * The image factory service.
   *
   * @var \Drupal\Core\Image\ImageFactory
   */
  protected $imageFactory;

  /**
   * The perceptual hash processor.
   *
   * @var \Drupal\vectorimg\ImageProcessor\PerceptualHash
   */
  protected $perceptualHash;

  /**
   * The color histogram processor.
   *
   * @var \Drupal\vectorimg\ImageProcessor\ColorHistogram
   */
  protected $colorHistogram;

  /**
   * The edge detection processor.
   *
   * @var \Drupal\vectorimg\ImageProcessor\EdgeDetection
   */
  protected $edgeDetection;

  /**
   * Constructs an ImageFeatureExtractor object.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The configuration factory.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger factory service.
   * @param \Drupal\Core\File\FileSystemInterface $file_system
   *   The file system service.
   * @param \Drupal\Core\Image\ImageFactory $image_factory
   *   The image factory service.
   * @param \Drupal\vectorimg\ImageProcessor\PerceptualHash $perceptual_hash
   *   The perceptual hash processor.
   * @param \Drupal\vectorimg\ImageProcessor\ColorHistogram $color_histogram
   *   The color histogram processor.
   * @param \Drupal\vectorimg\ImageProcessor\EdgeDetection $edge_detection
   *   The edge detection processor.
   */
  public function __construct(
    ConfigFactoryInterface $config_factory,
    LoggerChannelFactoryInterface $logger_factory,
    FileSystemInterface $file_system,
    ImageFactory $image_factory,
    PerceptualHash $perceptual_hash,
    ColorHistogram $color_histogram,
    EdgeDetection $edge_detection
  ) {
    $this->configFactory = $config_factory;
    $this->loggerFactory = $logger_factory->get('vectorimg');
    $this->fileSystem = $file_system;
    $this->imageFactory = $image_factory;
    $this->perceptualHash = $perceptual_hash;
    $this->colorHistogram = $color_histogram;
    $this->edgeDetection = $edge_detection;
  }

  /**
   * Extracts all image features for vector comparison.
   *
   * @param string $image_path
   *   Path to the image file.
   *
   * @return array
   *   An array of extracted features.
   */
  public function extractFeatures($image_path) {
    try {
      // Load the image with GD.
      $image = imagecreatefromstring(file_get_contents($image_path));
      
      if (!$image) {
        $this->loggerFactory->error('Failed to create image from @path', [
          '@path' => $image_path,
        ]);
        return [];
      }
      
      // Get image dimensions.
      $width = imagesx($image);
      $height = imagesy($image);
      
      // Create a normalized copy for processing.
      $config = $this->configFactory->get('vectorimg.settings');
      $target_size = $config->get('image_processing_dimensions');
      
      // Determine new dimensions preserving aspect ratio.
      if ($width > $height) {
        $new_width = $target_size;
        $new_height = round($height * ($target_size / $width));
      }
      else {
        $new_height = $target_size;
        $new_width = round($width * ($target_size / $height));
      }
      
      // Create normalized image.
      $normalized = imagecreatetruecolor($new_width, $new_height);
      imagecopyresampled($normalized, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
      
      // Extract basic features.
      $phash = $this->perceptualHash->generateHash($normalized);
      $color_histogram = $this->colorHistogram->generateHistogram($normalized);
      $edge_features = $this->edgeDetection->extractEdgeFeatures($normalized);
      
      // Extract advanced indexing features.
      $phash_parts = $this->perceptualHash->generateHashPartsString($phash);
      $dominant_colors = $this->colorHistogram->getDominantColorsString($normalized);
      $avg_color = $this->colorHistogram->getAverageColor($normalized);
      $aspect_ratio = $this->colorHistogram->getAspectRatio($normalized);
      
      // Clean up.
      imagedestroy($image);
      imagedestroy($normalized);
      
      return [
        // Basic features for similarity comparison.
        'phash' => $phash,
        'color_histogram' => serialize($color_histogram),
        'edge_features' => serialize($edge_features),
        
        // Advanced indexing features.
        'phash_parts' => $phash_parts,
        'dominant_colors' => $dominant_colors,
        'avg_color' => $avg_color,
        'aspect_ratio' => $aspect_ratio,
      ];
    }
    catch (\Exception $e) {
      $this->loggerFactory->error('Error extracting image features: @error', [
        '@error' => $e->getMessage(),
      ]);
      return [];
    }
  }

}