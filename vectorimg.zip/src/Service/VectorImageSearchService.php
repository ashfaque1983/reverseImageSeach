<?php

namespace Drupal\vectorimg\Service;

use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\media\MediaInterface;
use Drupal\file\Entity\File;
use Drupal\vectorimg\ImageProcessor\ImageFeatureExtractor;
use Drupal\vectorimg\ImageProcessor\VectorComparison;

/**
 * Provides vector image search functionality.
 */
class VectorImageSearchService {
  use StringTranslationTrait;

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The file system service.
   *
   * @var \Drupal\Core\File\FileSystemInterface
   */
  protected $fileSystem;

  /**
   * The configuration factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The logger factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * The image feature extractor.
   *
   * @var \Drupal\vectorimg\ImageProcessor\ImageFeatureExtractor
   */
  protected $featureExtractor;

  /**
   * The vector comparison service.
   *
   * @var \Drupal\vectorimg\ImageProcessor\VectorComparison
   */
  protected $vectorComparison;

  /**
   * Constructs a VectorImageSearchService object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\File\FileSystemInterface $file_system
   *   The file system service.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The configuration factory.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger channel factory service.
   * @param \Drupal\vectorimg\ImageProcessor\ImageFeatureExtractor $feature_extractor
   *   The image feature extractor.
   * @param \Drupal\vectorimg\ImageProcessor\VectorComparison $vector_comparison
   *   The vector comparison service.
   */
  public function __construct(
    Connection $database,
    EntityTypeManagerInterface $entity_type_manager,
    FileSystemInterface $file_system,
    ConfigFactoryInterface $config_factory,
    LoggerChannelFactoryInterface $logger_factory,
    ImageFeatureExtractor $feature_extractor,
    VectorComparison $vector_comparison
  ) {
    $this->database = $database;
    $this->entityTypeManager = $entity_type_manager;
    $this->fileSystem = $file_system;
    $this->configFactory = $config_factory;
    $this->loggerFactory = $logger_factory->get('vectorimg');
    $this->featureExtractor = $feature_extractor;
    $this->vectorComparison = $vector_comparison;
  }

  /**
   * Indexes a media image to extract and store feature vectors.
   *
   * @param \Drupal\media\MediaInterface $media
   *   The media entity containing an image to index.
   *
   * @return bool
   *   TRUE on success, FALSE on failure.
   */
  public function indexMediaImage(MediaInterface $media) {
    if ($media->bundle() !== 'image') {
      $this->loggerFactory->warning('Attempted to index non-image media entity: @mid', [
        '@mid' => $media->id(),
      ]);
      return FALSE;
    }

    try {
      // Get the image file.
      $field_name = 'field_media_image';
      $file_id = $media->$field_name->target_id;
      
      if (empty($file_id)) {
        $this->loggerFactory->warning('Media entity @mid has no image file', [
          '@mid' => $media->id(),
        ]);
        return FALSE;
      }
      
      $file = File::load($file_id);
      $image_uri = $file->getFileUri();
      
      // Extract image features.
      $features = $this->featureExtractor->extractFeatures($image_uri);
      
      if (empty($features)) {
        $this->loggerFactory->warning('Failed to extract features from image: @uri', [
          '@uri' => $image_uri,
        ]);
        return FALSE;
      }
      
      // Store features in the database.
      $this->storeImageFeatures($media->id(), $file_id, $features);
      
      return TRUE;
    }
    catch (\Exception $e) {
      $this->loggerFactory->error('Error indexing media image @mid: @error', [
        '@mid' => $media->id(),
        '@error' => $e->getMessage(),
      ]);
      return FALSE;
    }
  }

  /**
   * Stores image features in the database.
   *
   * @param int $mid
   *   The media entity ID.
   * @param int $fid
   *   The file entity ID.
   * @param array $features
   *   The extracted features array.
   */
  protected function storeImageFeatures($mid, $fid, array $features) {
    // Check if entry already exists.
    $existing = $this->database->select('vectorimg_features', 'vf')
      ->fields('vf', ['id'])
      ->condition('mid', $mid)
      ->execute()
      ->fetchField();
    
    $timestamp = \Drupal::time()->getRequestTime();
    
    if ($existing) {
      // Update existing record.
      $this->database->update('vectorimg_features')
        ->fields([
          'fid' => $fid,
          'phash' => $features['phash'],
          'phash_parts' => $features['phash_parts'],
          'color_histogram' => $features['color_histogram'],
          'edge_features' => $features['edge_features'],
          'dominant_colors' => $features['dominant_colors'],
          'avg_color' => $features['avg_color'],
          'aspect_ratio' => $features['aspect_ratio'],
          'updated' => $timestamp,
        ])
        ->condition('id', $existing)
        ->execute();
    }
    else {
      // Insert new record.
      $this->database->insert('vectorimg_features')
        ->fields([
          'mid' => $mid,
          'fid' => $fid,
          'phash' => $features['phash'],
          'phash_parts' => $features['phash_parts'],
          'color_histogram' => $features['color_histogram'],
          'edge_features' => $features['edge_features'],
          'dominant_colors' => $features['dominant_colors'],
          'avg_color' => $features['avg_color'],
          'aspect_ratio' => $features['aspect_ratio'],
          'created' => $timestamp,
          'updated' => $timestamp,
        ])
        ->execute();
    }
  }

  /**
   * Finds images similar to the provided image.
   *
   * @param string $image_path
   *   The path to the image to compare against.
   * @param float $similarity_threshold
   *   Minimum similarity percentage (0-100) for results.
   * @param array $weights
   *   Feature weights to use for similarity calculation.
   *
   * @return array
   *   Array of similar images sorted by similarity score.
   */
  public function findSimilarImages($image_path, $similarity_threshold = 0, array $weights = []) {
    try {
      // Get configuration.
      $config = $this->configFactory->get('vectorimg.settings');
      
      // Use default weights if not provided.
      if (empty($weights) || array_sum($weights) == 0) {
        $weights = [
          'color' => $config->get('default_feature_weights.color'),
          'edge' => $config->get('default_feature_weights.edge'),
          'phash' => $config->get('default_feature_weights.phash'),
        ];
      }
      
      // Normalize weights.
      $total_weight = array_sum($weights);
      foreach ($weights as $key => $weight) {
        $weights[$key] = $weight / $total_weight;
      }
      
      // Extract features from the query image.
      $query_features = $this->featureExtractor->extractFeatures($image_path);
      
      if (empty($query_features)) {
        throw new \Exception('Failed to extract features from the query image.');
      }
      
      // Step 1: Get candidate images using pre-filtering with indexing fields
      $candidates = $this->getFilteredCandidates($query_features);
      
      if (empty($candidates)) {
        // Fall back to using all images if no candidates found
        $candidates = $this->database->select('vectorimg_features', 'vf')
          ->fields('vf')
          ->execute()
          ->fetchAll();
      }
      
      // Calculate similarity for each candidate.
      $results = [];
      foreach ($candidates as $indexed_image) {
        $indexed_features = [
          'phash' => $indexed_image->phash,
          'color_histogram' => $indexed_image->color_histogram,
          'edge_features' => $indexed_image->edge_features,
        ];
        
        $similarity = $this->vectorComparison->calculateSimilarity(
          $query_features,
          $indexed_features,
          $weights
        );
        
        // Apply threshold filter.
        if ($similarity * 100 >= $similarity_threshold) {
          $results[] = [
            'mid' => $indexed_image->mid,
            'fid' => $indexed_image->fid,
            'similarity' => $similarity,
          ];
        }
      }
      
      // Sort by similarity (descending).
      usort($results, function ($a, $b) {
        return $b['similarity'] <=> $a['similarity'];
      });
      
      return $results;
    }
    catch (\Exception $e) {
      $this->loggerFactory->error('Error searching for similar images: @error', [
        '@error' => $e->getMessage(),
      ]);
      return [];
    }
  }
  
  /**
   * Gets a filtered set of candidate images using the advanced indexing fields.
   *
   * This method significantly reduces the number of images that need full
   * similarity comparison by using fast pre-filtering with indexed fields.
   *
   * @param array $query_features
   *   The features extracted from the query image.
   * @param int $limit
   *   Maximum number of candidates to return (0 = no limit).
   *
   * @return array
   *   Array of candidate image records.
   */
  protected function getFilteredCandidates(array $query_features, $limit = 0) {
    try {
      // Get configuration.
      $config = $this->configFactory->get('vectorimg.settings');
      
      // Step 1: Filter by perceptual hash parts for fast approximate matching.
      $hash_parts_query = $this->database->select('vectorimg_features', 'vf')
        ->fields('vf')
        ->condition('phash_parts', '%' . $this->database->escapeLike($query_features['phash_parts']) . '%', 'LIKE');
      
      // Add filtering by aspect ratio with tolerance (e.g., +/-10%).
      $aspect_ratio = $query_features['aspect_ratio'];
      $aspect_ratio_tolerance = 0.1; // 10% tolerance
      $hash_parts_query->condition('aspect_ratio', 
        [$aspect_ratio * (1 - $aspect_ratio_tolerance), $aspect_ratio * (1 + $aspect_ratio_tolerance)], 
        'BETWEEN');
      
      // Limit results (if specified).
      if ($limit > 0) {
        $hash_parts_query->range(0, $limit);
      }
      
      $hash_candidates = $hash_parts_query->execute()->fetchAll();
      
      // If we have enough candidates already, return them.
      if (count($hash_candidates) >= 50) {
        return $hash_candidates;
      }
      
      // Step 2: If not enough candidates, try filtering by dominant colors.
      $color_query = $this->database->select('vectorimg_features', 'vf')
        ->fields('vf')
        ->condition('dominant_colors', '%' . $this->database->escapeLike($query_features['dominant_colors']) . '%', 'LIKE')
        ->condition('aspect_ratio', 
          [$aspect_ratio * (1 - $aspect_ratio_tolerance), $aspect_ratio * (1 + $aspect_ratio_tolerance)], 
          'BETWEEN');
      
      if ($limit > 0) {
        $color_query->range(0, $limit);
      }
      
      $color_candidates = $color_query->execute()->fetchAll();
      
      // Combine candidates, prioritizing hash-based ones.
      $combined_candidates = [];
      $seen_mids = [];
      
      // Add hash candidates first.
      foreach ($hash_candidates as $candidate) {
        $combined_candidates[] = $candidate;
        $seen_mids[$candidate->mid] = TRUE;
      }
      
      // Add color candidates that aren't already included.
      foreach ($color_candidates as $candidate) {
        if (!isset($seen_mids[$candidate->mid])) {
          $combined_candidates[] = $candidate;
          $seen_mids[$candidate->mid] = TRUE;
          
          // Stop if we've reached the limit.
          if ($limit > 0 && count($combined_candidates) >= $limit) {
            break;
          }
        }
      }
      
      return $combined_candidates;
    }
    catch (\Exception $e) {
      $this->loggerFactory->error('Error getting filtered candidates: @error', [
        '@error' => $e->getMessage(),
      ]);
      return [];
    }
  }

}