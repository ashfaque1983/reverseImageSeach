<?php

namespace Drupal\vectorimg\Service;

use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\media\MediaInterface;
use Drupal\file\Entity\File;
use Drupal\vectorimg\ImageProcessor\ImageFeatureExtractor;
use Drupal\vectorimg\ImageProcessor\VectorComparison;

/**
 * Provides vector image search functionality.
 */
class VectorImageSearchService {
  use StringTranslationTrait;

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The file system service.
   *
   * @var \Drupal\Core\File\FileSystemInterface
   */
  protected $fileSystem;

  /**
   * The configuration factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The logger factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * The image feature extractor.
   *
   * @var \Drupal\vectorimg\ImageProcessor\ImageFeatureExtractor
   */
  protected $featureExtractor;

  /**
   * The vector comparison service.
   *
   * @var \Drupal\vectorimg\ImageProcessor\VectorComparison
   */
  protected $vectorComparison;

  /**
   * Constructs a VectorImageSearchService object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\File\FileSystemInterface $file_system
   *   The file system service.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The configuration factory.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger channel factory service.
   * @param \Drupal\vectorimg\ImageProcessor\ImageFeatureExtractor $feature_extractor
   *   The image feature extractor.
   * @param \Drupal\vectorimg\ImageProcessor\VectorComparison $vector_comparison
   *   The vector comparison service.
   */
  public function __construct(
    Connection $database,
    EntityTypeManagerInterface $entity_type_manager,
    FileSystemInterface $file_system,
    ConfigFactoryInterface $config_factory,
    LoggerChannelFactoryInterface $logger_factory,
    ImageFeatureExtractor $feature_extractor,
    VectorComparison $vector_comparison
  ) {
    $this->database = $database;
    $this->entityTypeManager = $entity_type_manager;
    $this->fileSystem = $file_system;
    $this->configFactory = $config_factory;
    $this->loggerFactory = $logger_factory->get('vectorimg');
    $this->featureExtractor = $feature_extractor;
    $this->vectorComparison = $vector_comparison;
  }

  /**
   * Indexes a media image to extract and store feature vectors.
   *
   * @param \Drupal\media\MediaInterface $media
   *   The media entity containing an image to index.
   *
   * @return bool
   *   TRUE on success, FALSE on failure.
   */
  public function indexMediaImage(MediaInterface $media) {
    if ($media->bundle() !== 'image') {
      $this->loggerFactory->warning('Attempted to index non-image media entity: @mid', [
        '@mid' => $media->id(),
      ]);
      return FALSE;
    }

    try {
      // Get the image file.
      $field_name = 'field_media_image';
      $file_id = $media->$field_name->target_id;
      
      if (empty($file_id)) {
        $this->loggerFactory->warning('Media entity @mid has no image file', [
          '@mid' => $media->id(),
        ]);
        return FALSE;
      }
      
      $file = File::load($file_id);
      $image_uri = $file->getFileUri();
      
      // Extract image features.
      $features = $this->featureExtractor->extractFeatures($image_uri);
      
      if (empty($features)) {
        $this->loggerFactory->warning('Failed to extract features from image: @uri', [
          '@uri' => $image_uri,
        ]);
        return FALSE;
      }
      
      // Store features in the database.
      $this->storeImageFeatures($media->id(), $file_id, $features);
      
      return TRUE;
    }
    catch (\Exception $e) {
      $this->loggerFactory->error('Error indexing media image @mid: @error', [
        '@mid' => $media->id(),
        '@error' => $e->getMessage(),
      ]);
      return FALSE;
    }
  }

  /**
   * Stores image features in the database.
   *
   * @param int $mid
   *   The media entity ID.
   * @param int $fid
   *   The file entity ID.
   * @param array $features
   *   The extracted features array.
   */
  protected function storeImageFeatures($mid, $fid, array $features) {
    // Check if entry already exists.
    $existing = $this->database->select('vectorimg_features', 'vf')
      ->fields('vf', ['id'])
      ->condition('mid', $mid)
      ->execute()
      ->fetchField();
    
    $timestamp = \Drupal::time()->getRequestTime();
    
    if ($existing) {
      // Update existing record.
      $this->database->update('vectorimg_features')
        ->fields([
          'fid' => $fid,
          'phash' => $features['phash'],
          'color_histogram' => $features['color_histogram'],
          'edge_features' => $features['edge_features'],
          'updated' => $timestamp,
        ])
        ->condition('id', $existing)
        ->execute();
    }
    else {
      // Insert new record.
      $this->database->insert('vectorimg_features')
        ->fields([
          'mid' => $mid,
          'fid' => $fid,
          'phash' => $features['phash'],
          'color_histogram' => $features['color_histogram'],
          'edge_features' => $features['edge_features'],
          'created' => $timestamp,
          'updated' => $timestamp,
        ])
        ->execute();
    }
  }

  /**
   * Finds images similar to the provided image.
   *
   * @param string $image_path
   *   The path to the image to compare against.
   * @param float $similarity_threshold
   *   Minimum similarity percentage (0-100) for results.
   * @param array $weights
   *   Feature weights to use for similarity calculation.
   *
   * @return array
   *   Array of similar images sorted by similarity score.
   */
  public function findSimilarImages($image_path, $similarity_threshold = 0, array $weights = []) {
    try {
      // Get configuration.
      $config = $this->configFactory->get('vectorimg.settings');
      
      // Use default weights if not provided.
      if (empty($weights) || array_sum($weights) == 0) {
        $weights = [
          'color' => $config->get('default_feature_weights.color'),
          'edge' => $config->get('default_feature_weights.edge'),
          'phash' => $config->get('default_feature_weights.phash'),
        ];
      }
      
      // Normalize weights.
      $total_weight = array_sum($weights);
      foreach ($weights as $key => $weight) {
        $weights[$key] = $weight / $total_weight;
      }
      
      // Extract features from the query image.
      $query_features = $this->featureExtractor->extractFeatures($image_path);
      
      if (empty($query_features)) {
        throw new \Exception('Failed to extract features from the query image.');
      }
      
      // Get all indexed images from the database.
      $indexed_images = $this->database->select('vectorimg_features', 'vf')
        ->fields('vf')
        ->execute()
        ->fetchAll();
      
      // Calculate similarity for each image.
      $results = [];
      foreach ($indexed_images as $indexed_image) {
        $indexed_features = [
          'phash' => $indexed_image->phash,
          'color_histogram' => $indexed_image->color_histogram,
          'edge_features' => $indexed_image->edge_features,
        ];
        
        $similarity = $this->vectorComparison->calculateSimilarity(
          $query_features,
          $indexed_features,
          $weights
        );
        
        // Apply threshold filter.
        if ($similarity * 100 >= $similarity_threshold) {
          $results[] = [
            'mid' => $indexed_image->mid,
            'fid' => $indexed_image->fid,
            'similarity' => $similarity,
          ];
        }
      }
      
      // Sort by similarity (descending).
      usort($results, function ($a, $b) {
        return $b['similarity'] <=> $a['similarity'];
      });
      
      return $results;
    }
    catch (\Exception $e) {
      $this->loggerFactory->error('Error searching for similar images: @error', [
        '@error' => $e->getMessage(),
      ]);
      return [];
    }
  }

}