<?php

namespace Drupal\vectorimg\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Drupal\Core\Url;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Core\Queue\QueueFactory;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\vectorimg\Service\VectorImageSearchService;

/**
 * Controller for the Vector Image Search module.
 */
class VectorImageSearchController extends ControllerBase {

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * The queue factory service.
   *
   * @var \Drupal\Core\Queue\QueueFactory
   */
  protected $queueFactory;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The vector image search service.
   *
   * @var \Drupal\vectorimg\Service\VectorImageSearchService
   */
  protected $vectorImageSearchService;

  /**
   * The messenger service.
   *
   * @var \Drupal\Core\Messenger\MessengerInterface
   */
  protected $messenger;

  /**
   * Constructs a VectorImageSearchController object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   * @param \Drupal\Core\Queue\QueueFactory $queue_factory
   *   The queue factory service.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\vectorimg\Service\VectorImageSearchService $vector_image_search_service
   *   The vector image search service.
   * @param \Drupal\Core\Messenger\MessengerInterface $messenger
   *   The messenger service.
   */
  public function __construct(
    Connection $database,
    QueueFactory $queue_factory,
    EntityTypeManagerInterface $entity_type_manager,
    VectorImageSearchService $vector_image_search_service,
    MessengerInterface $messenger
  ) {
    $this->database = $database;
    $this->queueFactory = $queue_factory;
    $this->entityTypeManager = $entity_type_manager;
    $this->vectorImageSearchService = $vector_image_search_service;
    $this->messenger = $messenger;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('database'),
      $container->get('queue'),
      $container->get('entity_type.manager'),
      $container->get('vectorimg.search_service'),
      $container->get('messenger')
    );
  }

  /**
   * Rebuilds the vector image search index.
   *
   * @return \Symfony\Component\HttpFoundation\RedirectResponse
   *   A redirect response to the settings page.
   */
  public function rebuildIndex() {
    // Clear existing index.
    $this->database->truncate('vectorimg_features')->execute();
    
    // Queue all images for re-indexing.
    $media_storage = $this->entityTypeManager->getStorage('media');
    $mids = $media_storage->getQuery()
      ->accessCheck(FALSE)
      ->condition('bundle', 'image')
      ->execute();
    
    if (!empty($mids)) {
      $queue = $this->queueFactory->get('vectorimg_index_processor');
      $queue->deleteQueue();
      $queue->createQueue();
      
      $batch_size = 50;
      $chunks = array_chunk($mids, $batch_size);
      
      foreach ($chunks as $chunk) {
        $queue->createItem(['media_ids' => $chunk]);
      }
      
      $this->messenger->addStatus($this->t('@count images have been queued for indexing. They will be processed during cron runs.', [
        '@count' => count($mids),
      ]));
    }
    else {
      $this->messenger->addStatus($this->t('No images found to index.'));
    }
    
    return new RedirectResponse(Url::fromRoute('vectorimg.settings')->toString());
  }

}