<?php

namespace Drupal\vectorimg\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Render\RendererInterface;
use Drupal\Core\Url;
use Drupal\file\Entity\File;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\Pager\PagerManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\vectorimg\Service\VectorImageSearchService;

/**
 * Provides a Vector Image Search form.
 */
class VectorImageSearchForm extends FormBase {

  /**
   * The file system service.
   *
   * @var \Drupal\Core\File\FileSystemInterface
   */
  protected $fileSystem;

  /**
   * The renderer service.
   *
   * @var \Drupal\Core\Render\RendererInterface
   */
  protected $renderer;

  /**
   * The config factory service.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The vector image search service.
   *
   * @var \Drupal\vectorimg\Service\VectorImageSearchService
   */
  protected $vectorImageSearchService;

  /**
   * The module handler service.
   *
   * @var \Drupal\Core\Extension\ModuleHandlerInterface
   */
  protected $moduleHandler;

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountProxyInterface
   */
  protected $currentUser;

  /**
   * The pager manager service.
   *
   * @var \Drupal\Core\Pager\PagerManagerInterface
   */
  protected $pagerManager;

  /**
   * Constructs a VectorImageSearchForm object.
   *
   * @param \Drupal\Core\File\FileSystemInterface $file_system
   *   The file system service.
   * @param \Drupal\Core\Render\RendererInterface $renderer
   *   The renderer service.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The configuration factory.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\vectorimg\Service\VectorImageSearchService $vector_image_search_service
   *   The vector image search service.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler service.
   * @param \Drupal\Core\Session\AccountProxyInterface $current_user
   *   The current user.
   * @param \Drupal\Core\Pager\PagerManagerInterface $pager_manager
   *   The pager manager service.
   */
  public function __construct(
    FileSystemInterface $file_system,
    RendererInterface $renderer,
    ConfigFactoryInterface $config_factory,
    EntityTypeManagerInterface $entity_type_manager,
    VectorImageSearchService $vector_image_search_service,
    ModuleHandlerInterface $module_handler,
    AccountProxyInterface $current_user,
    PagerManagerInterface $pager_manager
  ) {
    $this->fileSystem = $file_system;
    $this->renderer = $renderer;
    $this->configFactory = $config_factory;
    $this->entityTypeManager = $entity_type_manager;
    $this->vectorImageSearchService = $vector_image_search_service;
    $this->moduleHandler = $module_handler;
    $this->currentUser = $current_user;
    $this->pagerManager = $pager_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('file_system'),
      $container->get('renderer'),
      $container->get('config.factory'),
      $container->get('entity_type.manager'),
      $container->get('vectorimg.search_service'),
      $container->get('module_handler'),
      $container->get('current_user'),
      $container->get('pager.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'vectorimg_search_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->configFactory->get('vectorimg.settings');
    
    // Add CSS and JS.
    $form['#attached']['library'][] = 'vectorimg/vectorimg.assets';
    
    $form['#prefix'] = '<div class="vectorimg-form">';
    $form['#suffix'] = '</div>';
    
    // Source image selection.
    $form['image_source'] = [
      '#type' => 'details',
      '#title' => $this->t('Image source'),
      '#open' => TRUE,
    ];
    
    $form['image_source']['source_type'] = [
      '#type' => 'radios',
      '#title' => $this->t('Select image source'),
      '#options' => [
        'upload' => $this->t('Upload an image'),
        'media_library' => $this->t('Select from Media Library'),
      ],
      '#default_value' => 'upload',
    ];
    
    // Image upload.
    $form['image_source']['image_upload'] = [
      '#type' => 'file',
      '#title' => $this->t('Upload image'),
      '#description' => $this->t('Upload an image to search for similar images. Allowed extensions: jpg, jpeg, png, gif.'),
      '#states' => [
        'visible' => [
          ':input[name="source_type"]' => ['value' => 'upload'],
        ],
      ],
    ];
    
    // Media Library integration.
    $form['image_source']['media_id'] = [
      '#type' => 'entity_autocomplete',
      '#title' => $this->t('Select image from Media Library'),
      '#target_type' => 'media',
      '#selection_settings' => [
        'target_bundles' => ['image'],
      ],
      '#description' => $this->t('Type to search for an image in the Media Library.'),
      '#states' => [
        'visible' => [
          ':input[name="source_type"]' => ['value' => 'media_library'],
        ],
      ],
    ];
    
    // Search parameters.
    $form['search_parameters'] = [
      '#type' => 'details',
      '#title' => $this->t('Search parameters'),
      '#open' => TRUE,
    ];
    
    $form['search_parameters']['similarity_threshold'] = [
      '#type' => 'range',
      '#title' => $this->t('Similarity threshold'),
      '#min' => 0,
      '#max' => 100,
      '#step' => 1,
      '#default_value' => $config->get('default_similarity_threshold'),
      '#description' => $this->t('Minimum similarity percentage for results (0 = show all, 100 = exact matches only).'),
      '#attributes' => [
        'class' => ['similarity-slider'],
      ],
    ];
    
    // Feature weights.
    $form['search_parameters']['feature_weights'] = [
      '#type' => 'details',
      '#title' => $this->t('Feature weights'),
      '#description' => $this->t('Adjust the importance of each feature type in the similarity calculation.'),
      '#open' => FALSE,
    ];
    
    $form['search_parameters']['feature_weights']['color_weight'] = [
      '#type' => 'range',
      '#title' => $this->t('Color histogram weight'),
      '#min' => 0,
      '#max' => 100,
      '#step' => 1,
      '#default_value' => $config->get('default_feature_weights.color'),
      '#description' => $this->t('Weight for color distribution similarity.'),
    ];
    
    $form['search_parameters']['feature_weights']['edge_weight'] = [
      '#type' => 'range',
      '#title' => $this->t('Edge detection weight'),
      '#min' => 0,
      '#max' => 100,
      '#step' => 1,
      '#default_value' => $config->get('default_feature_weights.edge'),
      '#description' => $this->t('Weight for edge pattern similarity.'),
    ];
    
    $form['search_parameters']['feature_weights']['phash_weight'] = [
      '#type' => 'range',
      '#title' => $this->t('Perceptual hash weight'),
      '#min' => 0,
      '#max' => 100,
      '#step' => 1,
      '#default_value' => $config->get('default_feature_weights.phash'),
      '#description' => $this->t('Weight for perceptual hash similarity.'),
    ];
    
    // Submit button.
    $form['actions'] = [
      '#type' => 'actions',
    ];
    
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Search for similar images'),
    ];
    
    // Display search results if available.
    $results = $form_state->get('results');
    if ($results) {
      $form['results'] = [
        '#type' => 'markup',
        '#markup' => $this->renderer->render($results),
      ];
    }
    
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $source_type = $form_state->getValue('source_type');
    
    if ($source_type === 'upload') {
      // Validate file upload.
      $file_upload = $this->getRequest()->files->get('files', [])['image_upload'] ?? NULL;
      
      if (empty($file_upload)) {
        $form_state->setErrorByName('image_upload', $this->t('Please upload an image.'));
        return;
      }
      
      $file_extensions = ['jpg', 'jpeg', 'png', 'gif'];
      $validators = [
        'file_validate_extensions' => [implode(' ', $file_extensions)],
        'file_validate_is_image' => [],
      ];
      
      $file = file_save_upload('image_upload', $validators, 'temporary://vectorimg_query_image');
      
      if (!$file) {
        $form_state->setErrorByName('image_upload', $this->t('The uploaded file is not a valid image.'));
        return;
      }
      
      $form_state->setValue('file', $file);
    }
    elseif ($source_type === 'media_library') {
      // Validate media selection.
      $media_id = $form_state->getValue('media_id');
      
      if (empty($media_id)) {
        $form_state->setErrorByName('media_id', $this->t('Please select an image from the Media Library.'));
        return;
      }
      
      $media = $this->entityTypeManager->getStorage('media')->load($media_id);
      
      if (!$media || $media->bundle() !== 'image') {
        $form_state->setErrorByName('media_id', $this->t('The selected media item is not a valid image.'));
        return;
      }
    }
    
    // Validate feature weights.
    $color_weight = $form_state->getValue('color_weight');
    $edge_weight = $form_state->getValue('edge_weight');
    $phash_weight = $form_state->getValue('phash_weight');
    
    if (($color_weight + $edge_weight + $phash_weight) <= 0) {
      $form_state->setErrorByName('feature_weights', $this->t('The sum of feature weights must be greater than zero.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $source_type = $form_state->getValue('source_type');
    $config = $this->configFactory->get('vectorimg.settings');
    
    try {
      // Get source image.
      if ($source_type === 'upload') {
        // Use uploaded file.
        $file = $form_state->getValue('file');
        $file_uri = $file->getFileUri();
        $query_image_url = file_create_url($file_uri);
        $image = $file_uri;
      }
      else {
        // Use media library image.
        $media_id = $form_state->getValue('media_id');
        $media = $this->entityTypeManager->getStorage('media')->load($media_id);
        $field_name = 'field_media_image';
        $file_id = $media->$field_name->target_id;
        $file = File::load($file_id);
        $file_uri = $file->getFileUri();
        $query_image_url = file_create_url($file_uri);
        $image = $file_uri;
      }
      
      // Get search parameters.
      $similarity_threshold = $form_state->getValue('similarity_threshold');
      $weights = [
        'color' => $form_state->getValue('color_weight'),
        'edge' => $form_state->getValue('edge_weight'),
        'phash' => $form_state->getValue('phash_weight'),
      ];
      
      // Perform search.
      $results_per_page = $config->get('results_per_page');
      $raw_results = $this->vectorImageSearchService->findSimilarImages(
        $image,
        $similarity_threshold,
        $weights
      );
      
      // Set up pager.
      $total_results = count($raw_results);
      $this->pagerManager->createPager($total_results, $results_per_page);
      $pager = [
        '#type' => 'pager',
      ];
      
      // Get current page results.
      $page = $this->pagerManager->getPager()->getCurrentPage();
      $offset = $page * $results_per_page;
      $current_results = array_slice($raw_results, $offset, $results_per_page);
      
      // Build render array for results.
      $render_results = [];
      foreach ($current_results as $result) {
        $media = $this->entityTypeManager->getStorage('media')->load($result['mid']);
        if ($media) {
          $media_view_builder = $this->entityTypeManager->getViewBuilder('media');
          $thumbnail = $media_view_builder->view($media, 'thumbnail');
          
          $render_results[] = [
            'thumbnail' => $this->renderer->render($thumbnail),
            'title' => $media->label(),
            'similarity' => round($result['similarity'] * 100),
          ];
        }
      }
      
      // Build themed results.
      $results = [
        '#theme' => 'vectorimg_results',
        '#query_image' => $query_image_url,
        '#results' => $render_results,
        '#result_count' => $total_results,
        '#pager' => $pager,
      ];
      
      $form_state->set('results', $results);
      $form_state->setRebuild(TRUE);
    }
    catch (\Exception $e) {
      $this->messenger()->addError($this->t('An error occurred during the image search: @error', [
        '@error' => $e->getMessage(),
      ]));
      $this->logger('vectorimg')->error('Error during image search: @error', [
        '@error' => $e->getMessage(),
      ]);
    }
  }

}