<?php

namespace Drupal\vectorimg\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Database\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Configure Vector Image Search settings.
 */
class VectorImageSearchSettingsForm extends ConfigFormBase {

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * Constructs a VectorImageSearchSettingsForm object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   */
  public function __construct(Connection $database) {
    $this->database = $database;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('database')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'vectorimg_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['vectorimg.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('vectorimg.settings');

    // Index status.
    $index_count = $this->database->select('vectorimg_features', 'vf')
      ->countQuery()
      ->execute()
      ->fetchField();

    $media_image_count = $this->entityTypeManager()
      ->getStorage('media')
      ->getQuery()
      ->accessCheck(FALSE)
      ->condition('bundle', 'image')
      ->count()
      ->execute();

    $form['index_status'] = [
      '#type' => 'details',
      '#title' => $this->t('Index Status'),
      '#open' => TRUE,
    ];

    $form['index_status']['status'] = [
      '#markup' => $this->t('<p><strong>Images in Media Library:</strong> @total</p><p><strong>Images indexed:</strong> @indexed (@percent%)</p>', [
        '@total' => $media_image_count,
        '@indexed' => $index_count,
        '@percent' => $media_image_count > 0 ? round(($index_count / $media_image_count) * 100, 1) : 0,
      ]),
    ];

    $form['index_status']['rebuild'] = [
      '#type' => 'link',
      '#title' => $this->t('Rebuild index'),
      '#url' => Url::fromRoute('vectorimg.rebuild_index'),
      '#attributes' => [
        'class' => ['button', 'button--danger'],
      ],
    ];

    // Search settings.
    $form['search_settings'] = [
      '#type' => 'details',
      '#title' => $this->t('Search Settings'),
      '#open' => TRUE,
    ];

    $form['search_settings']['results_per_page'] = [
      '#type' => 'number',
      '#title' => $this->t('Results per page'),
      '#default_value' => $config->get('results_per_page'),
      '#min' => 5,
      '#max' => 100,
      '#step' => 5,
      '#description' => $this->t('Number of similar images to display per page.'),
      '#required' => TRUE,
    ];

    $form['search_settings']['default_similarity_threshold'] = [
      '#type' => 'number',
      '#title' => $this->t('Default similarity threshold'),
      '#default_value' => $config->get('default_similarity_threshold'),
      '#min' => 0,
      '#max' => 100,
      '#step' => 1,
      '#description' => $this->t('Default minimum similarity threshold percentage for search results.'),
      '#required' => TRUE,
    ];

    // Feature weights.
    $form['feature_weights'] = [
      '#type' => 'details',
      '#title' => $this->t('Default Feature Weights'),
      '#open' => TRUE,
      '#description' => $this->t('Set the default weights for each feature type. The effective weights will be normalized to sum to 100%.'),
    ];

    $form['feature_weights']['default_feature_weights_color'] = [
      '#type' => 'number',
      '#title' => $this->t('Color histogram weight'),
      '#default_value' => $config->get('default_feature_weights.color'),
      '#min' => 0,
      '#max' => 100,
      '#step' => 1,
      '#required' => TRUE,
    ];

    $form['feature_weights']['default_feature_weights_edge'] = [
      '#type' => 'number',
      '#title' => $this->t('Edge detection weight'),
      '#default_value' => $config->get('default_feature_weights.edge'),
      '#min' => 0,
      '#max' => 100,
      '#step' => 1,
      '#required' => TRUE,
    ];

    $form['feature_weights']['default_feature_weights_phash'] = [
      '#type' => 'number',
      '#title' => $this->t('Perceptual hash weight'),
      '#default_value' => $config->get('default_feature_weights.phash'),
      '#min' => 0,
      '#max' => 100,
      '#step' => 1,
      '#required' => TRUE,
    ];

    // Advanced settings.
    $form['advanced'] = [
      '#type' => 'details',
      '#title' => $this->t('Advanced Settings'),
      '#open' => FALSE,
    ];

    $form['advanced']['index_items_per_cron'] = [
      '#type' => 'number',
      '#title' => $this->t('Items to index per cron run'),
      '#default_value' => $config->get('index_items_per_cron'),
      '#min' => 5,
      '#max' => 200,
      '#step' => 5,
      '#description' => $this->t('Maximum number of images to index during each cron run.'),
      '#required' => TRUE,
    ];

    $form['advanced']['image_processing_dimensions'] = [
      '#type' => 'number',
      '#title' => $this->t('Image processing dimensions'),
      '#default_value' => $config->get('image_processing_dimensions'),
      '#min' => 64,
      '#max' => 512,
      '#step' => 16,
      '#description' => $this->t('Images will be resized to this dimension (preserving aspect ratio) before feature extraction for consistency and performance.'),
      '#required' => TRUE,
    ];

    $form['advanced']['color_histogram_bins'] = [
      '#type' => 'number',
      '#title' => $this->t('Color histogram bins'),
      '#default_value' => $config->get('color_histogram_bins'),
      '#min' => 8,
      '#max' => 64,
      '#step' => 8,
      '#description' => $this->t('Number of bins per color channel for color histogram. Higher values capture more color detail but increase processing time and storage requirements.'),
      '#required' => TRUE,
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    // Ensure feature weights sum to a positive value.
    $color_weight = $form_state->getValue('default_feature_weights_color');
    $edge_weight = $form_state->getValue('default_feature_weights_edge');
    $phash_weight = $form_state->getValue('default_feature_weights_phash');

    $total_weight = $color_weight + $edge_weight + $phash_weight;

    if ($total_weight <= 0) {
      $form_state->setError($form['feature_weights'], $this->t('The sum of all feature weights must be greater than zero.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('vectorimg.settings')
      ->set('results_per_page', $form_state->getValue('results_per_page'))
      ->set('default_similarity_threshold', $form_state->getValue('default_similarity_threshold'))
      ->set('default_feature_weights.color', $form_state->getValue('default_feature_weights_color'))
      ->set('default_feature_weights.edge', $form_state->getValue('default_feature_weights_edge'))
      ->set('default_feature_weights.phash', $form_state->getValue('default_feature_weights_phash'))
      ->set('index_items_per_cron', $form_state->getValue('index_items_per_cron'))
      ->set('image_processing_dimensions', $form_state->getValue('image_processing_dimensions'))
      ->set('color_histogram_bins', $form_state->getValue('color_histogram_bins'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}