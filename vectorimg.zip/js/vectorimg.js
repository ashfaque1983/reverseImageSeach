/**
 * @file
 * JavaScript for the Vector Image Search module.
 */

(function ($, Drupal, drupalSettings) {
  'use strict';

  Drupal.behaviors.vectorImageSearch = {
    attach: function (context, settings) {
      // File upload preview
      $('.vectorimg-form .form-item-image-upload input[type="file"]', context).once('vector-search').on('change', function (e) {
        // Show preview of uploaded image
        const fileInput = e.target;
        if (fileInput.files && fileInput.files[0]) {
          // Create preview container if it doesn't exist
          let previewContainer = $('.image-upload-preview');
          if (previewContainer.length === 0) {
            previewContainer = $('<div class="image-upload-preview"></div>');
            $(fileInput).closest('.form-item').append(previewContainer);
          }
          
          // Show preview
          const reader = new FileReader();
          reader.onload = function (e) {
            previewContainer.html('<div class="preview-label">' + Drupal.t('Preview:') + '</div><img src="' + e.target.result + '" alt="' + Drupal.t('Preview') + '" />');
            previewContainer.show();
          };
          reader.readAsDataURL(fileInput.files[0]);
        }
      });
      
      // Range input value display
      $('.vectorimg-form input[type="range"]', context).once('vector-search').each(function() {
        const rangeInput = $(this);
        const valueDisplay = $('<div class="range-value"></div>');
        
        // Add value display after each range input
        rangeInput.after(valueDisplay);
        
        // Initial value
        valueDisplay.text(rangeInput.val());
        
        // Update on change
        rangeInput.on('input change', function() {
          valueDisplay.text($(this).val());
        });
      });
      
      // Feature weights adjustment - ensure they sum to 100
      const adjustWeights = function() {
        const colorWeight = parseInt($('#edit-color-weight').val());
        const edgeWeight = parseInt($('#edit-edge-weight').val());
        const phashWeight = parseInt($('#edit-phash-weight').val());
        
        const totalWeight = colorWeight + edgeWeight + phashWeight;
        
        if (totalWeight > 0) {
          const normalizedTotal = $('.weights-total');
          if (normalizedTotal.length === 0) {
            const totalDisplay = $('<div class="weights-total"></div>');
            $('.feature-weights-summary').remove();
            $('#edit-feature-weights').append('<div class="feature-weights-summary"><strong>' + Drupal.t('Weights Summary') + ':</strong></div>');
            $('#edit-feature-weights').append(totalDisplay);
            
            // Display normalized weights
            const weightsDisplay = $('<div class="normalized-weights"></div>');
            $('#edit-feature-weights').append(weightsDisplay);
            
            totalDisplay.text(Drupal.t('Total: @total%', {'@total': totalWeight}));
            
            const normalizedColor = Math.round((colorWeight / totalWeight) * 100);
            const normalizedEdge = Math.round((edgeWeight / totalWeight) * 100);
            const normalizedPhash = 100 - normalizedColor - normalizedEdge;
            
            weightsDisplay.html(
              Drupal.t('Effective weights: Color: @color%, Edge: @edge%, Perceptual Hash: @phash%', {
                '@color': normalizedColor,
                '@edge': normalizedEdge,
                '@phash': normalizedPhash
              })
            );
          } else {
            normalizedTotal.text(Drupal.t('Total: @total%', {'@total': totalWeight}));
            
            const normalizedColor = Math.round((colorWeight / totalWeight) * 100);
            const normalizedEdge = Math.round((edgeWeight / totalWeight) * 100);
            const normalizedPhash = 100 - normalizedColor - normalizedEdge;
            
            $('.normalized-weights').html(
              Drupal.t('Effective weights: Color: @color%, Edge: @edge%, Perceptual Hash: @phash%', {
                '@color': normalizedColor,
                '@edge': normalizedEdge,
                '@phash': normalizedPhash
              })
            );
          }
        }
      };
      
      // Initialize and update feature weights display
      $('#edit-feature-weights input[type="range"]', context).once('vector-search-weights').on('input change', adjustWeights);
      
      // Run once on page load if all weight inputs are present
      if ($('#edit-color-weight').length && $('#edit-edge-weight').length && $('#edit-phash-weight').length) {
        adjustWeights();
      }
      
      // Apply CSS to similarity bars for better visualization
      $('.similarity-fill', context).once('vector-search').each(function() {
        const similarity = parseFloat($(this).css('width')) / parseFloat($(this).parent().css('width'));
        
        // Apply different colors based on similarity value
        if (similarity >= 0.8) {
          $(this).css('background', 'linear-gradient(to right, #4CAF50, #8BC34A)');
        } else if (similarity >= 0.6) {
          $(this).css('background', 'linear-gradient(to right, #FFC107, #FFEB3B)');
        } else if (similarity >= 0.4) {
          $(this).css('background', 'linear-gradient(to right, #FF9800, #FFC107)');
        } else {
          $(this).css('background', 'linear-gradient(to right, #F44336, #FF9800)');
        }
      });
    }
  };

})(jQuery, Drupal, drupalSettings);