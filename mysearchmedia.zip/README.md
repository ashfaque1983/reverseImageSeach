# Media Image Search for Drupal 10.3

A custom Drupal 10.3 module that implements vector-based image search for Media Library without third-party dependencies.

## Overview

The Media Image Search module allows users to find similar images in the Drupal Media Library by:
- Uploading an image as a search query
- Applying multiple complementary image analysis techniques:
  - Perceptual Hash
  - Color Histogram
  - Edge Detection
- Adjusting search parameters for different kinds of similarity

All processing happens directly in PHP, with no external services or APIs required.

## Requirements

- Drupal 10.3 or higher
- PHP 8.0 or higher with GD extension
- Media and Media Library modules enabled

## Installation

### Manual Installation

1. Download the module ZIP file
2. Extract the contents to your Drupal site's `modules/custom` directory:
   ```
   cd [drupal-root]/modules/custom/
   mkdir mysearchmedia
   unzip path/to/mysearchmedia.zip -d mysearchmedia
   ```
3. Navigate to "Extend" in your Drupal admin menu
4. Find and check "Media Image Search" in the modules list
5. Click "Install" at the bottom of the page

### Using Composer (alternative)

```
composer require custom/mysearchmedia
drush en mysearchmedia
```

## Configuration

1. After installing the module, go to **Configuration → Media → Media Image Search**
2. Configure default settings:
   - **Results per page**: Number of results to display (default: 20)
   - **Default similarity threshold**: Minimum similarity percentage (default: 60%)
   - **Feature weights**: Relative importance of each image feature:
     - Color distribution
     - Edge features
     - Perceptual hash
   - **Advanced settings**: Image processing parameters

## Usage

### Basic Usage

1. Go to **Content → Media Image Search**
2. Upload an image file (JPEG, PNG, GIF)
3. Set the similarity threshold (optional)
4. Adjust feature weights (optional)
5. Click "Search"
6. Browse through the results, which show:
   - Thumbnail of each similar image
   - Similarity score as a percentage
   - Visual indicators of similarity strength

### Advanced Usage

The module uses three complementary image analysis techniques:

1. **Perceptual Hash (pHash)**: Finds visually similar images even if they have been resized, compressed, or slightly edited
2. **Color Histogram**: Finds images with similar color distribution
3. **Edge Detection**: Finds images with similar shapes and structures

To fine-tune your search:
- Increase Color weight to find images with similar colors
- Increase Edge weight to find images with similar shapes
- Increase pHash weight to find images that look generally similar

## Maintenance

### Indexing

The module automatically indexes images in your Media Library:
- New images are indexed when uploaded
- Modified images are re-indexed
- Index status is displayed on the settings page
- You can manually rebuild the index from the settings page

### Troubleshooting

If you encounter issues:

1. Verify PHP memory limits are adequate (image processing can be memory-intensive)
2. Check error logs if indexing fails
3. Rebuild the index if search results seem inconsistent
4. Ensure GD library is properly installed

## Credits

Developed by your development team.

## License

This module is provided under the GPL v2 or later.