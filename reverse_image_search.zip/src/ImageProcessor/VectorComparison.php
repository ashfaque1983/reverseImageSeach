<?php

namespace Drupal\reverse_image_search\ImageProcessor;

/**
 * Service for comparing feature vectors.
 */
class VectorComparison {

  /**
   * Calculates cosine similarity between two vectors.
   *
   * @param array $vector1
   *   The first vector.
   * @param array $vector2
   *   The second vector.
   *
   * @return float
   *   Similarity value between 0 and 1 (1 = most similar).
   */
  public function cosineSimilarity(array $vector1, array $vector2) {
    // Ensure both vectors are the same size
    if (count($vector1) !== count($vector2)) {
      throw new \InvalidArgumentException('Vectors must be of the same size for cosine similarity calculation.');
    }
    
    $dot_product = 0;
    $magnitude1 = 0;
    $magnitude2 = 0;
    
    for ($i = 0; $i < count($vector1); $i++) {
      $dot_product += $vector1[$i] * $vector2[$i];
      $magnitude1 += $vector1[$i] * $vector1[$i];
      $magnitude2 += $vector2[$i] * $vector2[$i];
    }
    
    $magnitude1 = sqrt($magnitude1);
    $magnitude2 = sqrt($magnitude2);
    
    // Prevent division by zero
    if ($magnitude1 == 0 || $magnitude2 == 0) {
      return 0;
    }
    
    // Calculate cosine similarity
    $similarity = $dot_product / ($magnitude1 * $magnitude2);
    
    // Ensure result is within 0-1 range
    return max(0, min(1, $similarity));
  }

  /**
   * Calculates Euclidean distance between two vectors.
   *
   * @param array $vector1
   *   The first vector.
   * @param array $vector2
   *   The second vector.
   *
   * @return float
   *   The Euclidean distance.
   */
  public function euclideanDistance(array $vector1, array $vector2) {
    // Ensure both vectors are the same size
    if (count($vector1) !== count($vector2)) {
      throw new \InvalidArgumentException('Vectors must be of the same size for Euclidean distance calculation.');
    }
    
    $sum_squares = 0;
    
    for ($i = 0; $i < count($vector1); $i++) {
      $diff = $vector1[$i] - $vector2[$i];
      $sum_squares += $diff * $diff;
    }
    
    return sqrt($sum_squares);
  }

  /**
   * Normalizes Euclidean distance to a similarity score.
   *
   * @param float $distance
   *   The Euclidean distance.
   * @param float $max_distance
   *   The maximum possible distance.
   *
   * @return float
   *   Similarity value between 0 and 1.
   */
  public function distanceToSimilarity($distance, $max_distance) {
    // Ensure max_distance is positive
    if ($max_distance <= 0) {
      return 0;
    }
    
    // Convert distance to similarity (1 means identical, 0 means completely different)
    return 1 - min(1, $distance / $max_distance);
  }

  /**
   * Calculates Manhattan distance between two vectors.
   *
   * @param array $vector1
   *   The first vector.
   * @param array $vector2
   *   The second vector.
   *
   * @return float
   *   The Manhattan distance.
   */
  public function manhattanDistance(array $vector1, array $vector2) {
    // Ensure both vectors are the same size
    if (count($vector1) !== count($vector2)) {
      throw new \InvalidArgumentException('Vectors must be of the same size for Manhattan distance calculation.');
    }
    
    $sum = 0;
    
    for ($i = 0; $i < count($vector1); $i++) {
      $sum += abs($vector1[$i] - $vector2[$i]);
    }
    
    return $sum;
  }

  /**
   * Combines multiple similarity scores with weighted average.
   *
   * @param array $scores
   *   Array of similarity scores.
   * @param array $weights
   *   Array of weights for each score.
   *
   * @return float
   *   Combined similarity score.
   */
  public function combineScores(array $scores, array $weights) {
    // Ensure both arrays are the same size
    if (count($scores) !== count($weights)) {
      throw new \InvalidArgumentException('Scores and weights arrays must be of the same size.');
    }
    
    // Ensure weights sum to 1
    $total_weight = array_sum($weights);
    if ($total_weight == 0) {
      return 0;
    }
    
    // Normalize weights if they don't sum to 1
    if (abs($total_weight - 1) > 0.0001) {
      foreach ($weights as &$weight) {
        $weight /= $total_weight;
      }
    }
    
    // Calculate weighted average
    $weighted_sum = 0;
    for ($i = 0; $i < count($scores); $i++) {
      $weighted_sum += $scores[$i] * $weights[$i];
    }
    
    return $weighted_sum;
  }
}
