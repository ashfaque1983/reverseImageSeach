<?php

namespace Drupal\reverse_image_search\ImageProcessor;

use Drupal\Core\Logger\LoggerChannelFactoryInterface;

/**
 * Service for edge detection and shape analysis in images.
 */
class EdgeDetection {

  /**
   * The logger channel factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * Constructs an EdgeDetection object.
   *
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger channel factory.
   */
  public function __construct(LoggerChannelFactoryInterface $logger_factory) {
    $this->loggerFactory = $logger_factory;
  }

  /**
   * Detects edges in an image and generates edge features.
   *
   * @param resource $image
   *   The GD image resource.
   *
   * @return array
   *   Edge features as a normalized vector.
   */
  public function detectEdges($image) {
    try {
      $width = imagesx($image);
      $height = imagesy($image);
      
      // Create grayscale version of the image
      $grayscale = imagecreatetruecolor($width, $height);
      
      // Convert to grayscale
      for ($y = 0; $y < $height; $y++) {
        for ($x = 0; $x < $width; $x++) {
          $rgb = imagecolorat($image, $x, $y);
          $r = ($rgb >> 16) & 0xFF;
          $g = ($rgb >> 8) & 0xFF;
          $b = $rgb & 0xFF;
          $gray = (int) (0.299 * $r + 0.587 * $g + 0.114 * $b);
          imagesetpixel($grayscale, $x, $y, imagecolorallocate($grayscale, $gray, $gray, $gray));
        }
      }
      
      // Define Sobel operators for edge detection
      $sobel_x = [
        [-1, 0, 1],
        [-2, 0, 2],
        [-1, 0, 1],
      ];
      
      $sobel_y = [
        [-1, -2, -1],
        [0, 0, 0],
        [1, 2, 1],
      ];
      
      // Apply Sobel operators to detect edges
      $edges = imagecreatetruecolor($width, $height);
      
      // Initialize edge magnitude matrix
      $edge_magnitude = [];
      $max_magnitude = 0;
      
      for ($y = 1; $y < $height - 1; $y++) {
        for ($x = 1; $x < $width - 1; $x++) {
          $gx = 0;
          $gy = 0;
          
          // Apply convolution with Sobel operators
          for ($ky = -1; $ky <= 1; $ky++) {
            for ($kx = -1; $kx <= 1; $kx++) {
              $pixel = imagecolorat($grayscale, $x + $kx, $y + $ky);
              $gray = ($pixel >> 16) & 0xFF; // All channels are the same in grayscale
              
              $gx += $gray * $sobel_x[$ky + 1][$kx + 1];
              $gy += $gray * $sobel_y[$ky + 1][$kx + 1];
            }
          }
          
          // Calculate gradient magnitude
          $magnitude = sqrt($gx * $gx + $gy * $gy);
          $edge_magnitude[$y][$x] = $magnitude;
          
          // Track maximum magnitude for normalization
          $max_magnitude = max($max_magnitude, $magnitude);
          
          // Set edge pixel
          $edge_value = min(255, $magnitude);
          imagesetpixel($edges, $x, $y, imagecolorallocate($edges, $edge_value, $edge_value, $edge_value));
        }
      }
      
      // Create a 16x16 grid for edge feature representation
      $grid_size = 16;
      $cell_width = $width / $grid_size;
      $cell_height = $height / $grid_size;
      
      // Initialize edge feature vector
      $edge_features = [];
      
      // Compute average edge magnitude for each grid cell
      for ($gy = 0; $gy < $grid_size; $gy++) {
        for ($gx = 0; $gx < $grid_size; $gx++) {
          $cell_sum = 0;
          $count = 0;
          
          // Calculate cell boundaries
          $y_start = (int) ($gy * $cell_height);
          $y_end = (int) (($gy + 1) * $cell_height);
          $x_start = (int) ($gx * $cell_width);
          $x_end = (int) (($gx + 1) * $cell_width);
          
          // Sum edge magnitudes in this cell
          for ($y = $y_start; $y < $y_end; $y++) {
            for ($x = $x_start; $x < $x_end; $x++) {
              if (isset($edge_magnitude[$y][$x])) {
                $cell_sum += $edge_magnitude[$y][$x];
                $count++;
              }
            }
          }
          
          // Calculate cell average and normalize
          $cell_avg = ($count > 0 && $max_magnitude > 0) ? $cell_sum / ($count * $max_magnitude) : 0;
          $edge_features[] = $cell_avg;
        }
      }
      
      // Free memory
      imagedestroy($grayscale);
      imagedestroy($edges);
      
      return $edge_features;
    }
    catch (\Exception $e) {
      $this->loggerFactory->get('reverse_image_search')->error('Error in edge detection: @error', ['@error' => $e->getMessage()]);
      throw $e;
    }
  }

  /**
   * Compares two sets of edge features.
   *
   * @param array $features1
   *   First set of edge features.
   * @param array $features2
   *   Second set of edge features.
   *
   * @return float
   *   Similarity score between 0 and 1 (1 = most similar).
   */
  public function compareEdgeFeatures(array $features1, array $features2) {
    // Ensure both feature sets are the same size
    if (count($features1) != count($features2)) {
      // If different sizes, resize the smaller one
      if (count($features1) < count($features2)) {
        $features1 = $this->resizeFeatures($features1, count($features2));
      }
      else {
        $features2 = $this->resizeFeatures($features2, count($features1));
      }
    }
    
    // Calculate cosine similarity
    $dot_product = 0;
    $magnitude1 = 0;
    $magnitude2 = 0;
    
    for ($i = 0; $i < count($features1); $i++) {
      $dot_product += $features1[$i] * $features2[$i];
      $magnitude1 += $features1[$i] * $features1[$i];
      $magnitude2 += $features2[$i] * $features2[$i];
    }
    
    $magnitude1 = sqrt($magnitude1);
    $magnitude2 = sqrt($magnitude2);
    
    // Prevent division by zero
    if ($magnitude1 == 0 || $magnitude2 == 0) {
      return 0;
    }
    
    // Calculate cosine similarity
    $similarity = $dot_product / ($magnitude1 * $magnitude2);
    
    // Ensure result is within 0-1 range
    return max(0, min(1, $similarity));
  }

  /**
   * Resizes a feature vector to a new size.
   *
   * @param array $features
   *   The feature vector to resize.
   * @param int $new_size
   *   The target size.
   *
   * @return array
   *   The resized feature vector.
   */
  protected function resizeFeatures(array $features, $new_size) {
    // If the original is empty, return new empty array
    if (empty($features)) {
      return array_fill(0, $new_size, 0);
    }
    
    $old_size = count($features);
    $new_features = [];
    
    // Simple linear interpolation
    for ($i = 0; $i < $new_size; $i++) {
      $pos = $i * ($old_size - 1) / ($new_size - 1);
      $index = (int) $pos;
      $fraction = $pos - $index;
      
      if ($index < $old_size - 1) {
        $new_features[$i] = $features[$index] * (1 - $fraction) + $features[$index + 1] * $fraction;
      }
      else {
        $new_features[$i] = $features[$index];
      }
    }
    
    return $new_features;
  }
}
