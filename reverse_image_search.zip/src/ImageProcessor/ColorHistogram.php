<?php

namespace Drupal\reverse_image_search\ImageProcessor;

use Drupal\Core\Logger\LoggerChannelFactoryInterface;

/**
 * Service for generating and comparing color histograms of images.
 */
class ColorHistogram {

  /**
   * The logger channel factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * Constructs a ColorHistogram object.
   *
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger channel factory.
   */
  public function __construct(LoggerChannelFactoryInterface $logger_factory) {
    $this->loggerFactory = $logger_factory;
  }

  /**
   * Generates a color histogram from an image.
   *
   * @param resource $image
   *   The GD image resource.
   * @param int $num_bins
   *   Number of bins per color channel.
   *
   * @return array
   *   The color histogram as an array of normalized bin values.
   */
  public function generateHistogram($image, $num_bins = 32) {
    try {
      $width = imagesx($image);
      $height = imagesy($image);
      
      // Initialize bins
      $bins_per_channel = max(2, min($num_bins, 256));
      $bin_size = 256 / $bins_per_channel;
      
      // Initialize histogram
      $histogram = [];
      for ($r = 0; $r < $bins_per_channel; $r++) {
        for ($g = 0; $g < $bins_per_channel; $g++) {
          for ($b = 0; $b < $bins_per_channel; $b++) {
            $histogram[$r][$g][$b] = 0;
          }
        }
      }
      
      // Count pixels
      $total_pixels = 0;
      for ($y = 0; $y < $height; $y++) {
        for ($x = 0; $x < $width; $x++) {
          $rgb = imagecolorat($image, $x, $y);
          
          // Skip fully transparent pixels
          $alpha = ($rgb & 0x7F000000) >> 24;
          if ($alpha == 127) {
            continue;
          }
          
          $r = ($rgb >> 16) & 0xFF;
          $g = ($rgb >> 8) & 0xFF;
          $b = $rgb & 0xFF;
          
          // Determine which bin this pixel goes into
          $r_bin = min($bins_per_channel - 1, floor($r / $bin_size));
          $g_bin = min($bins_per_channel - 1, floor($g / $bin_size));
          $b_bin = min($bins_per_channel - 1, floor($b / $bin_size));
          
          $histogram[$r_bin][$g_bin][$b_bin]++;
          $total_pixels++;
        }
      }
      
      // Normalize histogram
      if ($total_pixels > 0) {
        for ($r = 0; $r < $bins_per_channel; $r++) {
          for ($g = 0; $g < $bins_per_channel; $g++) {
            for ($b = 0; $b < $bins_per_channel; $b++) {
              $histogram[$r][$g][$b] = $histogram[$r][$g][$b] / $total_pixels;
            }
          }
        }
      }
      
      // Flatten histogram for storage
      $flat_histogram = [];
      for ($r = 0; $r < $bins_per_channel; $r++) {
        for ($g = 0; $g < $bins_per_channel; $g++) {
          for ($b = 0; $b < $bins_per_channel; $b++) {
            $flat_histogram[] = $histogram[$r][$g][$b];
          }
        }
      }
      
      return $flat_histogram;
    }
    catch (\Exception $e) {
      $this->loggerFactory->get('reverse_image_search')->error('Error generating color histogram: @error', ['@error' => $e->getMessage()]);
      throw $e;
    }
  }

  /**
   * Compares two color histograms using the Bhattacharyya distance.
   *
   * @param array $hist1
   *   The first color histogram.
   * @param array $hist2
   *   The second color histogram.
   *
   * @return float
   *   Similarity score between 0 and 1 (1 = most similar).
   */
  public function compareHistograms(array $hist1, array $hist2) {
    // Ensure the histograms are of the same size
    if (count($hist1) !== count($hist2)) {
      // Resize the smaller histogram to match the larger one
      if (count($hist1) < count($hist2)) {
        $hist1 = $this->resizeHistogram($hist1, count($hist2));
      }
      else {
        $hist2 = $this->resizeHistogram($hist2, count($hist1));
      }
    }
    
    // Calculate Bhattacharyya coefficient (BC)
    $bc = 0;
    for ($i = 0; $i < count($hist1); $i++) {
      $bc += sqrt($hist1[$i] * $hist2[$i]);
    }
    
    // BC ranges from 0 to 1, where 1 is perfect match
    return $bc;
  }

  /**
   * Resizes a histogram to a target size.
   *
   * @param array $histogram
   *   The histogram to resize.
   * @param int $target_size
   *   The target size.
   *
   * @return array
   *   The resized histogram.
   */
  protected function resizeHistogram(array $histogram, $target_size) {
    // If the target size is smaller, downsample by combining bins
    if ($target_size < count($histogram)) {
      $factor = count($histogram) / $target_size;
      $new_histogram = array_fill(0, $target_size, 0);
      
      for ($i = 0; $i < count($histogram); $i++) {
        $index = min($target_size - 1, (int) floor($i / $factor));
        $new_histogram[$index] += $histogram[$i];
      }
      
      // Normalize
      $sum = array_sum($new_histogram);
      if ($sum > 0) {
        for ($i = 0; $i < $target_size; $i++) {
          $new_histogram[$i] /= $sum;
        }
      }
      
      return $new_histogram;
    }
    
    // If the target size is larger, upsample with linear interpolation
    $new_histogram = array_fill(0, $target_size, 0);
    $factor = (count($histogram) - 1) / ($target_size - 1);
    
    for ($i = 0; $i < $target_size; $i++) {
      $pos = $i * $factor;
      $index = min(count($histogram) - 2, (int) floor($pos));
      $fraction = $pos - $index;
      
      $new_histogram[$i] = $histogram[$index] * (1 - $fraction) + $histogram[$index + 1] * $fraction;
    }
    
    return $new_histogram;
  }
}
