<?php

namespace Drupal\reverse_image_search\ImageProcessor;

use Drupal\Core\File\FileSystemInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;

/**
 * Main service for extracting image features.
 */
class ImageFeatureExtractor {

  /**
   * The file system service.
   *
   * @var \Drupal\Core\File\FileSystemInterface
   */
  protected $fileSystem;

  /**
   * The module handler service.
   *
   * @var \Drupal\Core\Extension\ModuleHandlerInterface
   */
  protected $moduleHandler;

  /**
   * The configuration factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The logger channel factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * The perceptual hash service.
   *
   * @var \Drupal\reverse_image_search\ImageProcessor\PerceptualHash
   */
  protected $perceptualHash;

  /**
   * The color histogram service.
   *
   * @var \Drupal\reverse_image_search\ImageProcessor\ColorHistogram
   */
  protected $colorHistogram;

  /**
   * The edge detection service.
   *
   * @var \Drupal\reverse_image_search\ImageProcessor\EdgeDetection
   */
  protected $edgeDetection;

  /**
   * Constructs an ImageFeatureExtractor object.
   *
   * @param \Drupal\Core\File\FileSystemInterface $file_system
   *   The file system service.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler service.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The configuration factory.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger channel factory.
   * @param \Drupal\reverse_image_search\ImageProcessor\PerceptualHash $perceptual_hash
   *   The perceptual hash service.
   * @param \Drupal\reverse_image_search\ImageProcessor\ColorHistogram $color_histogram
   *   The color histogram service.
   * @param \Drupal\reverse_image_search\ImageProcessor\EdgeDetection $edge_detection
   *   The edge detection service.
   */
  public function __construct(
    FileSystemInterface $file_system,
    ModuleHandlerInterface $module_handler,
    ConfigFactoryInterface $config_factory,
    LoggerChannelFactoryInterface $logger_factory,
    PerceptualHash $perceptual_hash,
    ColorHistogram $color_histogram,
    EdgeDetection $edge_detection
  ) {
    $this->fileSystem = $file_system;
    $this->moduleHandler = $module_handler;
    $this->configFactory = $config_factory;
    $this->loggerFactory = $logger_factory;
    $this->perceptualHash = $perceptual_hash;
    $this->colorHistogram = $color_histogram;
    $this->edgeDetection = $edge_detection;
  }

  /**
   * Creates a resource from an image file.
   *
   * @param string $file_uri
   *   The URI of the image file.
   *
   * @return resource|false
   *   The image resource, or FALSE on failure.
   */
  public function createImageResource($file_uri) {
    if (!file_exists($file_uri)) {
      throw new \InvalidArgumentException("Image file does not exist: $file_uri");
    }

    $image_info = getimagesize($file_uri);
    if ($image_info === false) {
      throw new \InvalidArgumentException("Not a valid image file: $file_uri");
    }

    $mime_type = $image_info['mime'];
    $image = false;

    switch ($mime_type) {
      case 'image/jpeg':
        $image = imagecreatefromjpeg($file_uri);
        break;
      case 'image/png':
        $image = imagecreatefrompng($file_uri);
        break;
      case 'image/gif':
        $image = imagecreatefromgif($file_uri);
        break;
      case 'image/webp':
        $image = imagecreatefromwebp($file_uri);
        break;
      default:
        throw new \InvalidArgumentException("Unsupported image format: $mime_type");
    }

    if ($image === false) {
      throw new \RuntimeException("Failed to create image resource from file: $file_uri");
    }

    // Set blending mode for PNGs with transparency
    if ($mime_type === 'image/png') {
      imagealphablending($image, true);
      imagesavealpha($image, true);
    }

    return $image;
  }

  /**
   * Resizes an image resource to specified dimensions.
   *
   * @param resource $image
   *   The image resource.
   * @param int $width
   *   The target width.
   * @param int $height
   *   The target height.
   *
   * @return resource
   *   The resized image resource.
   */
  public function resizeImage($image, $width, $height) {
    $original_width = imagesx($image);
    $original_height = imagesy($image);

    // If image is already the right size, return it
    if ($original_width == $width && $original_height == $height) {
      return $image;
    }

    $resized = imagecreatetruecolor($width, $height);
    
    // Preserve transparency in resized image
    imagealphablending($resized, false);
    imagesavealpha($resized, true);
    
    imagecopyresampled(
      $resized,
      $image,
      0, 0, 0, 0,
      $width, $height,
      $original_width, $original_height
    );

    return $resized;
  }

  /**
   * Extracts all image features and returns as an array.
   *
   * @param string $file_uri
   *   The URI of the image file.
   *
   * @return array
   *   An array of image features.
   */
  public function extractFeatures($file_uri) {
    // Get configuration
    $config = $this->configFactory->get('reverse_image_search.settings');
    $resize_dimensions = $config->get('image_resize_dimensions') ?? 256;
    $color_bins = $config->get('color_bins') ?? 32;

    try {
      // Create image resource
      $image = $this->createImageResource($file_uri);
      
      // Resize for feature extraction
      $resized = $this->resizeImage($image, $resize_dimensions, $resize_dimensions);
      
      // Extract perceptual hash
      $phash = $this->perceptualHash->generateHash($resized);
      
      // Extract color histogram
      $color_histogram = $this->colorHistogram->generateHistogram($resized, $color_bins);
      
      // Extract edge features
      $edge_features = $this->edgeDetection->detectEdges($resized);
      
      // Free memory
      imagedestroy($resized);
      if ($image !== $resized) {
        imagedestroy($image);
      }
      
      return [
        'phash' => $phash,
        'color_histogram' => $color_histogram,
        'edge_features' => $edge_features,
      ];
    }
    catch (\Exception $e) {
      $this->loggerFactory->get('reverse_image_search')->error('Error extracting image features: @error', ['@error' => $e->getMessage()]);
      throw $e;
    }
  }

  /**
   * Compares features between a query image and stored features.
   *
   * @param array $query_features
   *   Features extracted from the query image.
   * @param array $stored_features
   *   Features stored in the database.
   * @param array $weights
   *   Weights for different feature types.
   *
   * @return float
   *   Similarity score between 0 and 1.
   */
  public function compareFeatures(array $query_features, array $stored_features, array $weights) {
    // Default weights if not provided
    $weights = $weights + [
      'phash' => 0.34,
      'color' => 0.33,
      'edge' => 0.33,
    ];
    
    // Normalize weights to sum to 1
    $total_weight = array_sum($weights);
    if ($total_weight > 0) {
      foreach ($weights as &$weight) {
        $weight = $weight / $total_weight;
      }
    }
    
    // Compare perceptual hash (lower distance is better)
    $phash_similarity = 0;
    if (!empty($query_features['phash']) && !empty($stored_features['phash'])) {
      $phash_distance = $this->perceptualHash->calculateDistance(
        $query_features['phash'],
        $stored_features['phash']
      );
      // Convert distance to similarity (0-1 scale)
      $phash_similarity = 1 - min($phash_distance / 64, 1);
    }
    
    // Compare color histograms
    $color_similarity = 0;
    if (!empty($query_features['color_histogram']) && !empty($stored_features['color_histogram'])) {
      $color_similarity = $this->colorHistogram->compareHistograms(
        $query_features['color_histogram'],
        $stored_features['color_histogram']
      );
    }
    
    // Compare edge features
    $edge_similarity = 0;
    if (!empty($query_features['edge_features']) && !empty($stored_features['edge_features'])) {
      $edge_similarity = $this->edgeDetection->compareEdgeFeatures(
        $query_features['edge_features'],
        $stored_features['edge_features']
      );
    }
    
    // Calculate weighted similarity score
    $similarity_score = 
      ($weights['phash'] * $phash_similarity) +
      ($weights['color'] * $color_similarity) +
      ($weights['edge'] * $edge_similarity);
    
    return $similarity_score;
  }
}
