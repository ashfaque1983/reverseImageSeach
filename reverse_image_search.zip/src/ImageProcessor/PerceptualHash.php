<?php

namespace Drupal\reverse_image_search\ImageProcessor;

use Drupal\Core\Logger\LoggerChannelFactoryInterface;

/**
 * Service for generating and comparing perceptual hashes of images.
 */
class PerceptualHash {

  /**
   * The logger channel factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * Constructs a PerceptualHash object.
   *
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger channel factory.
   */
  public function __construct(LoggerChannelFactoryInterface $logger_factory) {
    $this->loggerFactory = $logger_factory;
  }

  /**
   * Generates a perceptual hash (pHash) from an image.
   *
   * @param resource $image
   *   The GD image resource.
   *
   * @return string
   *   The perceptual hash as a 64-character hex string.
   */
  public function generateHash($image) {
    try {
      // Resize the image to 32x32 pixels
      $img32 = imagecreatetruecolor(32, 32);
      imagecopyresampled($img32, $image, 0, 0, 0, 0, 32, 32, imagesx($image), imagesy($image));
      
      // Convert to grayscale
      imagefilter($img32, IMG_FILTER_GRAYSCALE);
      
      // Resize to 8x8 for DCT
      $img8 = imagecreatetruecolor(8, 8);
      imagecopyresampled($img8, $img32, 0, 0, 0, 0, 8, 8, 32, 32);
      
      // Get grayscale pixel values
      $pixels = [];
      for ($y = 0; $y < 8; $y++) {
        for ($x = 0; $x < 8; $x++) {
          $rgb = imagecolorat($img8, $x, $y);
          $r = ($rgb >> 16) & 0xFF;
          $g = ($rgb >> 8) & 0xFF;
          $b = $rgb & 0xFF;
          $pixels[$y][$x] = round(($r + $g + $b) / 3);
        }
      }
      
      // Apply Discrete Cosine Transform (simplified version)
      $dct = $this->simpleDCT($pixels);
      
      // Calculate the average value (excluding the first term)
      $total = 0;
      $count = 0;
      
      for ($y = 0; $y < 8; $y++) {
        for ($x = 0; $x < 8; $x++) {
          // Skip the first term (DC coefficient)
          if ($y === 0 && $x === 0) {
            continue;
          }
          $total += $dct[$y][$x];
          $count++;
        }
      }
      
      $avg = $total / $count;
      
      // Generate the hash based on whether values are above or below the average
      $hash = '';
      for ($y = 0; $y < 8; $y++) {
        for ($x = 0; $x < 8; $x++) {
          // Skip the first term
          if ($y === 0 && $x === 0) {
            continue;
          }
          $hash .= ($dct[$y][$x] > $avg) ? '1' : '0';
        }
      }
      
      // Free memory
      imagedestroy($img32);
      imagedestroy($img8);
      
      // Convert binary hash to hexadecimal for storage
      $hex_hash = '';
      for ($i = 0; $i < strlen($hash); $i += 4) {
        $hex_hash .= dechex(bindec(substr($hash, $i, 4)));
      }
      
      return str_pad($hex_hash, 16, '0', STR_PAD_LEFT);
    }
    catch (\Exception $e) {
      $this->loggerFactory->get('reverse_image_search')->error('Error generating perceptual hash: @error', ['@error' => $e->getMessage()]);
      throw $e;
    }
  }

  /**
   * Simplified implementation of Discrete Cosine Transform.
   *
   * @param array $pixels
   *   2D array of grayscale pixel values.
   *
   * @return array
   *   2D array of DCT coefficients.
   */
  protected function simpleDCT(array $pixels) {
    $size = 8;
    $dct = array_fill(0, $size, array_fill(0, $size, 0.0));
    
    for ($u = 0; $u < $size; $u++) {
      for ($v = 0; $v < $size; $v++) {
        $sum = 0.0;
        for ($y = 0; $y < $size; $y++) {
          for ($x = 0; $x < $size; $x++) {
            $sum += $pixels[$y][$x] * 
                   cos((2 * $x + 1) * $u * M_PI / (2 * $size)) * 
                   cos((2 * $y + 1) * $v * M_PI / (2 * $size));
          }
        }
        
        // Apply scaling factors
        $cu = ($u === 0) ? 1 / sqrt(2) : 1;
        $cv = ($v === 0) ? 1 / sqrt(2) : 1;
        $dct[$v][$u] = 0.25 * $cu * $cv * $sum;
      }
    }
    
    return $dct;
  }

  /**
   * Calculates the Hamming distance between two hashes.
   *
   * @param string $hash1
   *   First perceptual hash (hex string).
   * @param string $hash2
   *   Second perceptual hash (hex string).
   *
   * @return int
   *   The Hamming distance (number of differing bits).
   */
  public function calculateDistance($hash1, $hash2) {
    // Convert hex hashes to binary
    $binary1 = $this->hexToBin($hash1);
    $binary2 = $this->hexToBin($hash2);
    
    // Ensure both binary strings are the same length
    $len = max(strlen($binary1), strlen($binary2));
    $binary1 = str_pad($binary1, $len, '0', STR_PAD_LEFT);
    $binary2 = str_pad($binary2, $len, '0', STR_PAD_LEFT);
    
    // Calculate Hamming distance
    $distance = 0;
    for ($i = 0; $i < $len; $i++) {
      if (isset($binary1[$i]) && isset($binary2[$i]) && $binary1[$i] !== $binary2[$i]) {
        $distance++;
      }
    }
    
    return $distance;
  }

  /**
   * Converts a hexadecimal string to binary.
   *
   * @param string $hex
   *   Hexadecimal string.
   *
   * @return string
   *   Binary string.
   */
  protected function hexToBin($hex) {
    $bin = '';
    for ($i = 0; $i < strlen($hex); $i++) {
      $binary = decbin(hexdec($hex[$i]));
      $bin .= str_pad($binary, 4, '0', STR_PAD_LEFT);
    }
    return $bin;
  }
}
