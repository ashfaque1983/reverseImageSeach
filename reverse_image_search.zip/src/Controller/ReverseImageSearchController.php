<?php

namespace Drupal\reverse_image_search\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\reverse_image_search\Service\ReverseImageSearchService;
use Drupal\Core\File\FileSystemInterface;
use Drupal\file\Entity\File;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Cache\CacheableJsonResponse;
use Drupal\Core\Cache\CacheableMetadata;

/**
 * Controller for reverse image search operations.
 */
class ReverseImageSearchController extends ControllerBase {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The reverse image search service.
   *
   * @var \Drupal\reverse_image_search\Service\ReverseImageSearchService
   */
  protected $reverseImageSearchService;

  /**
   * The file system service.
   *
   * @var \Drupal\Core\File\FileSystemInterface
   */
  protected $fileSystem;

  /**
   * Constructs a ReverseImageSearchController object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\reverse_image_search\Service\ReverseImageSearchService $reverse_image_search_service
   *   The reverse image search service.
   * @param \Drupal\Core\File\FileSystemInterface $file_system
   *   The file system service.
   */
  public function __construct(
    EntityTypeManagerInterface $entity_type_manager,
    ReverseImageSearchService $reverse_image_search_service,
    FileSystemInterface $file_system
  ) {
    $this->entityTypeManager = $entity_type_manager;
    $this->reverseImageSearchService = $reverse_image_search_service;
    $this->fileSystem = $file_system;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('reverse_image_search.service'),
      $container->get('file_system')
    );
  }

  /**
   * Checks access for the reverse image search AJAX endpoint.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The account requesting access.
   *
   * @return \Drupal\Core\Access\AccessResultInterface
   *   The access result.
   */
  public function access(AccountInterface $account) {
    return AccessResult::allowedIfHasPermission($account, 'access reverse image search');
  }

  /**
   * AJAX endpoint for reverse image search.
   *
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   The current request.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   *   JSON response with search results.
   */
  public function ajaxSearch(Request $request) {
    $file_id = $request->query->get('fid');
    
    if (!$file_id) {
      return new JsonResponse(['error' => 'Missing file ID parameter.'], 400);
    }
    
    $file = File::load($file_id);
    if (!$file) {
      return new JsonResponse(['error' => 'Invalid file ID.'], 404);
    }
    
    $config = $this->config('reverse_image_search.settings');
    
    $similarity_threshold = $request->query->get('threshold', $config->get('default_similarity_threshold') ?? 60) / 100;
    
    $color_weight = $request->query->get('color_weight', $config->get('default_color_weight') ?? 40);
    $edge_weight = $request->query->get('edge_weight', $config->get('default_edge_weight') ?? 30);
    $phash_weight = $request->query->get('phash_weight', $config->get('default_phash_weight') ?? 30);
    
    $total_weight = $color_weight + $edge_weight + $phash_weight;
    if ($total_weight > 0) {
      $weights = [
        'color' => $color_weight / $total_weight,
        'edge' => $edge_weight / $total_weight,
        'phash' => $phash_weight / $total_weight,
      ];
    }
    else {
      $weights = [
        'color' => 0.33,
        'edge' => 0.33,
        'phash' => 0.34,
      ];
    }
    
    $limit = $request->query->get('limit', $config->get('results_per_page') ?? 20);
    $offset = $request->query->get('offset', 0);
    
    try {
      $results = $this->reverseImageSearchService->searchSimilarImages(
        $file->getFileUri(),
        $similarity_threshold,
        $weights,
        $limit,
        $offset
      );
      
      // Build response data
      $response_data = [
        'count' => count($results),
        'results' => [],
      ];
      
      foreach ($results as $result) {
        $media = $this->entityTypeManager->getStorage('media')->load($result['mid']);
        if ($media) {
          $response_data['results'][] = [
            'mid' => $result['mid'],
            'title' => $media->label(),
            'similarity' => $result['similarity'],
            'url' => $media->toUrl()->toString(),
            'thumbnail' => $this->getThumbnailUrl($media),
          ];
        }
      }
      
      // Create a cacheable response
      $response = new CacheableJsonResponse($response_data);
      $cache_metadata = new CacheableMetadata();
      $cache_metadata->setCacheMaxAge(3600); // Cache for 1 hour
      $response->addCacheableDependency($cache_metadata);
      
      return $response;
    }
    catch (\Exception $e) {
      $this->getLogger('reverse_image_search')->error('AJAX search error: @error', ['@error' => $e->getMessage()]);
      return new JsonResponse(['error' => $e->getMessage()], 500);
    }
  }
  
  /**
   * Get the thumbnail URL for a media entity.
   *
   * @param \Drupal\media\MediaInterface $media
   *   The media entity.
   *
   * @return string|null
   *   The thumbnail URL or NULL if not available.
   */
  protected function getThumbnailUrl($media) {
    if ($media->hasField('thumbnail')) {
      $thumbnail = $media->get('thumbnail')->entity;
      if ($thumbnail) {
        $image_style = $this->entityTypeManager->getStorage('image_style')->load('medium');
        if ($image_style) {
          return $image_style->buildUrl($thumbnail->getFileUri());
        }
        return file_create_url($thumbnail->getFileUri());
      }
    }
    return NULL;
  }
}
