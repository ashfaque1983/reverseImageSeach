<?php

namespace Drupal\reverse_image_search\Service;

use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\reverse_image_search\ImageProcessor\ImageFeatureExtractor;
use Drupal\reverse_image_search\ImageProcessor\VectorComparison;
use Drupal\media\MediaInterface;
use Drupal\file\FileInterface;

/**
 * Main service for reverse image search functionality.
 */
class ReverseImageSearchService {

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The file system service.
   *
   * @var \Drupal\Core\File\FileSystemInterface
   */
  protected $fileSystem;

  /**
   * The configuration factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The logger channel factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * The image feature extractor service.
   *
   * @var \Drupal\reverse_image_search\ImageProcessor\ImageFeatureExtractor
   */
  protected $imageFeatureExtractor;

  /**
   * The vector comparison service.
   *
   * @var \Drupal\reverse_image_search\ImageProcessor\VectorComparison
   */
  protected $vectorComparison;

  /**
   * Constructs a ReverseImageSearchService object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\File\FileSystemInterface $file_system
   *   The file system service.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The configuration factory.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger channel factory.
   * @param \Drupal\reverse_image_search\ImageProcessor\ImageFeatureExtractor $image_feature_extractor
   *   The image feature extractor service.
   * @param \Drupal\reverse_image_search\ImageProcessor\VectorComparison $vector_comparison
   *   The vector comparison service.
   */
  public function __construct(
    Connection $database,
    EntityTypeManagerInterface $entity_type_manager,
    FileSystemInterface $file_system,
    ConfigFactoryInterface $config_factory,
    LoggerChannelFactoryInterface $logger_factory,
    ImageFeatureExtractor $image_feature_extractor,
    VectorComparison $vector_comparison
  ) {
    $this->database = $database;
    $this->entityTypeManager = $entity_type_manager;
    $this->fileSystem = $file_system;
    $this->configFactory = $config_factory;
    $this->loggerFactory = $logger_factory;
    $this->imageFeatureExtractor = $image_feature_extractor;
    $this->vectorComparison = $vector_comparison;
  }

  /**
   * Extracts and stores image features for a media entity.
   *
   * @param int|\Drupal\media\MediaInterface $media
   *   Media entity or ID.
   *
   * @return bool
   *   TRUE if successful, FALSE otherwise.
   */
  public function indexMediaImage($media) {
    try {
      if (!$media instanceof MediaInterface) {
        $media = $this->entityTypeManager->getStorage('media')->load($media);
      }
      
      if (!$media) {
        $this->loggerFactory->get('reverse_image_search')->error('Failed to load media entity for indexing.');
        return FALSE;
      }
      
      // Get the image file from the media entity
      $file = $this->getImageFileFromMedia($media);
      if (!$file) {
        $this->loggerFactory->get('reverse_image_search')->error('Media entity @id does not have a valid image file.', ['@id' => $media->id()]);
        return FALSE;
      }
      
      // Extract image features
      $features = $this->imageFeatureExtractor->extractFeatures($file->getFileUri());
      
      // Store features in the database
      return $this->storeImageFeatures($media->id(), $file->id(), $features);
    }
    catch (\Exception $e) {
      $this->loggerFactory->get('reverse_image_search')->error('Error indexing media image: @error', ['@error' => $e->getMessage()]);
      return FALSE;
    }
  }

  /**
   * Gets the image file from a media entity.
   *
   * @param \Drupal\media\MediaInterface $media
   *   The media entity.
   *
   * @return \Drupal\file\FileInterface|null
   *   The file entity or NULL if not found.
   */
  protected function getImageFileFromMedia(MediaInterface $media) {
    // Try standard image field names
    $field_names = ['field_media_image', 'image', 'thumbnail'];
    
    foreach ($field_names as $field_name) {
      if ($media->hasField($field_name)) {
        $file_ref = $media->get($field_name);
        if (!$file_ref->isEmpty()) {
          $file = $file_ref->entity;
          if ($file instanceof FileInterface) {
            return $file;
          }
        }
      }
    }
    
    // If standard fields not found, look for any field of type 'image' or 'file'
    foreach ($media->getFields() as $field_name => $field) {
      $field_type = $field->getFieldDefinition()->getType();
      if (in_array($field_type, ['image', 'file'])) {
        $file_ref = $media->get($field_name);
        if (!$file_ref->isEmpty()) {
          $file = $file_ref->entity;
          if ($file instanceof FileInterface) {
            return $file;
          }
        }
      }
    }
    
    return NULL;
  }

  /**
   * Stores image features in the database.
   *
   * @param int $mid
   *   Media entity ID.
   * @param int $fid
   *   File entity ID.
   * @param array $features
   *   Image features.
   *
   * @return bool
   *   TRUE if successful, FALSE otherwise.
   */
  protected function storeImageFeatures($mid, $fid, array $features) {
    try {
      // Check if features for this media already exist
      $existing = $this->database->select('reverse_image_search_vectors', 'v')
        ->fields('v', ['id'])
        ->condition('mid', $mid)
        ->execute()
        ->fetchField();
      
      $time = \Drupal::time()->getRequestTime();
      
      if ($existing) {
        // Update existing record
        return $this->database->update('reverse_image_search_vectors')
          ->fields([
            'fid' => $fid,
            'phash' => $features['phash'],
            'color_histogram' => serialize($features['color_histogram']),
            'edge_features' => serialize($features['edge_features']),
            'updated' => $time,
          ])
          ->condition('id', $existing)
          ->execute();
      }
      else {
        // Insert new record
        return $this->database->insert('reverse_image_search_vectors')
          ->fields([
            'mid' => $mid,
            'fid' => $fid,
            'phash' => $features['phash'],
            'color_histogram' => serialize($features['color_histogram']),
            'edge_features' => serialize($features['edge_features']),
            'created' => $time,
            'updated' => $time,
          ])
          ->execute();
      }
    }
    catch (\Exception $e) {
      $this->loggerFactory->get('reverse_image_search')->error('Error storing image features: @error', ['@error' => $e->getMessage()]);
      return FALSE;
    }
  }

  /**
   * Searches for similar images to the provided query image.
   *
   * @param string $query_image_uri
   *   URI of the query image.
   * @param float $threshold
   *   Minimum similarity threshold (0 to 1).
   * @param array $weights
   *   Weights for different feature types.
   * @param int $limit
   *   Maximum number of results to return.
   * @param int $offset
   *   Offset for pagination.
   *
   * @return array
   *   Array of search results with similarity scores.
   */
  public function searchSimilarImages($query_image_uri, $threshold = 0.6, array $weights = [], $limit = 20, $offset = 0) {
    try {
      // Extract features from the query image
      $query_features = $this->imageFeatureExtractor->extractFeatures($query_image_uri);
      
      // Set default weights if not provided
      $weights = $weights + [
        'color' => 0.33,
        'edge' => 0.33,
        'phash' => 0.34,
      ];
      
      // Fetch all image vectors from the database
      $vectors = $this->database->select('reverse_image_search_vectors', 'v')
        ->fields('v')
        ->execute()
        ->fetchAll();
      
      $results = [];
      
      foreach ($vectors as $vector) {
        // Unserialize stored features
        $stored_features = [
          'phash' => $vector->phash,
          'color_histogram' => unserialize($vector->color_histogram),
          'edge_features' => unserialize($vector->edge_features),
        ];
        
        // Compare features
        $similarity = $this->imageFeatureExtractor->compareFeatures(
          $query_features,
          $stored_features,
          $weights
        );
        
        // Filter by threshold
        if ($similarity >= $threshold) {
          $results[] = [
            'mid' => $vector->mid,
            'fid' => $vector->fid,
            'similarity' => $similarity,
          ];
        }
      }
      
      // Sort by similarity (highest first)
      usort($results, function ($a, $b) {
        return $b['similarity'] <=> $a['similarity'];
      });
      
      // Apply limit and offset
      return array_slice($results, $offset, $limit);
    }
    catch (\Exception $e) {
      $this->loggerFactory->get('reverse_image_search')->error('Error searching for similar images: @error', ['@error' => $e->getMessage()]);
      throw $e;
    }
  }

  /**
   * Gets the number of indexed images.
   *
   * @return int
   *   The count of indexed images.
   */
  public function getIndexedImageCount() {
    return $this->database->select('reverse_image_search_vectors', 'v')
      ->countQuery()
      ->execute()
      ->fetchField();
  }

  /**
   * Clears the image feature index.
   *
   * @return bool
   *   TRUE if successful, FALSE otherwise.
   */
  public function clearIndex() {
    try {
      $this->database->truncate('reverse_image_search_vectors')->execute();
      return TRUE;
    }
    catch (\Exception $e) {
      $this->loggerFactory->get('reverse_image_search')->error('Error clearing image index: @error', ['@error' => $e->getMessage()]);
      return FALSE;
    }
  }

  /**
   * Removes a media item from the index.
   *
   * @param int $mid
   *   The media entity ID.
   *
   * @return bool
   *   TRUE if successful, FALSE otherwise.
   */
  public function removeFromIndex($mid) {
    try {
      $this->database->delete('reverse_image_search_vectors')
        ->condition('mid', $mid)
        ->execute();
      return TRUE;
    }
    catch (\Exception $e) {
      $this->loggerFactory->get('reverse_image_search')->error('Error removing media from index: @error', ['@error' => $e->getMessage()]);
      return FALSE;
    }
  }
}
