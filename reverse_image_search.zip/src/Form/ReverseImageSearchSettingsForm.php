<?php

namespace Drupal\reverse_image_search\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Queue\QueueFactory;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\reverse_image_search\Service\ReverseImageSearchService;

/**
 * Configure Reverse Image Search settings.
 */
class ReverseImageSearchSettingsForm extends ConfigFormBase {

  /**
   * The queue factory.
   *
   * @var \Drupal\Core\Queue\QueueFactory
   */
  protected $queueFactory;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The reverse image search service.
   *
   * @var \Drupal\reverse_image_search\Service\ReverseImageSearchService
   */
  protected $reverseImageSearchService;

  /**
   * Constructs a ReverseImageSearchSettingsForm object.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The factory for configuration objects.
   * @param \Drupal\Core\Queue\QueueFactory $queue_factory
   *   The queue factory.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\reverse_image_search\Service\ReverseImageSearchService $reverse_image_search_service
   *   The reverse image search service.
   */
  public function __construct(
    ConfigFactoryInterface $config_factory,
    QueueFactory $queue_factory,
    EntityTypeManagerInterface $entity_type_manager,
    ReverseImageSearchService $reverse_image_search_service
  ) {
    parent::__construct($config_factory);
    $this->queueFactory = $queue_factory;
    $this->entityTypeManager = $entity_type_manager;
    $this->reverseImageSearchService = $reverse_image_search_service;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('queue'),
      $container->get('entity_type.manager'),
      $container->get('reverse_image_search.service')
    );
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'reverse_image_search.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'reverse_image_search_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('reverse_image_search.settings');

    $form['general_settings'] = [
      '#type' => 'details',
      '#title' => $this->t('General Settings'),
      '#open' => TRUE,
    ];
    
    $form['general_settings']['results_per_page'] = [
      '#type' => 'number',
      '#title' => $this->t('Results per page'),
      '#description' => $this->t('Number of search results to display per page.'),
      '#default_value' => $config->get('results_per_page') ?? 20,
      '#min' => 1,
      '#max' => 100,
      '#required' => TRUE,
    ];
    
    $form['general_settings']['default_similarity_threshold'] = [
      '#type' => 'number',
      '#title' => $this->t('Default similarity threshold (%)'),
      '#description' => $this->t('Default minimum similarity score for search results (0-100).'),
      '#default_value' => $config->get('default_similarity_threshold') ?? 60,
      '#min' => 0,
      '#max' => 100,
      '#required' => TRUE,
    ];
    
    $form['feature_weights'] = [
      '#type' => 'details',
      '#title' => $this->t('Default Feature Weights'),
      '#description' => $this->t('Set the default importance of different image features for comparison.'),
      '#open' => TRUE,
    ];
    
    $form['feature_weights']['default_color_weight'] = [
      '#type' => 'number',
      '#title' => $this->t('Color Weight'),
      '#description' => $this->t('Default weight given to color features (0-100).'),
      '#default_value' => $config->get('default_color_weight') ?? 40,
      '#min' => 0,
      '#max' => 100,
      '#required' => TRUE,
    ];
    
    $form['feature_weights']['default_edge_weight'] = [
      '#type' => 'number',
      '#title' => $this->t('Edge/Shape Weight'),
      '#description' => $this->t('Default weight given to edge/shape features (0-100).'),
      '#default_value' => $config->get('default_edge_weight') ?? 30,
      '#min' => 0,
      '#max' => 100,
      '#required' => TRUE,
    ];
    
    $form['feature_weights']['default_phash_weight'] = [
      '#type' => 'number',
      '#title' => $this->t('Perceptual Hash Weight'),
      '#description' => $this->t('Default weight given to perceptual hash comparison (0-100).'),
      '#default_value' => $config->get('default_phash_weight') ?? 30,
      '#min' => 0,
      '#max' => 100,
      '#required' => TRUE,
    ];
    
    $form['advanced'] = [
      '#type' => 'details',
      '#title' => $this->t('Advanced Settings'),
      '#open' => FALSE,
    ];
    
    $form['advanced']['image_resize_dimensions'] = [
      '#type' => 'number',
      '#title' => $this->t('Image Processing Dimensions'),
      '#description' => $this->t('Size to resize images to before feature extraction (larger values may improve accuracy but increase processing time).'),
      '#default_value' => $config->get('image_resize_dimensions') ?? 256,
      '#min' => 32,
      '#max' => 1024,
      '#required' => TRUE,
    ];
    
    $form['advanced']['color_bins'] = [
      '#type' => 'number',
      '#title' => $this->t('Color Histogram Bins'),
      '#description' => $this->t('Number of bins for color histogram (higher values capture more color detail but may be slower).'),
      '#default_value' => $config->get('color_bins') ?? 32,
      '#min' => 8,
      '#max' => 256,
      '#required' => TRUE,
    ];
    
    $form['indexing'] = [
      '#type' => 'details',
      '#title' => $this->t('Media Indexing'),
      '#open' => TRUE,
    ];

    // Get indexing stats
    $indexed_count = $this->reverseImageSearchService->getIndexedImageCount();
    $media_image_count = $this->getTotalMediaImageCount();
    
    $form['indexing']['stats'] = [
      '#type' => 'item',
      '#markup' => $this->t('Current indexing status: @indexed out of @total media items indexed.', [
        '@indexed' => $indexed_count,
        '@total' => $media_image_count,
      ]),
    ];
    
    $form['indexing']['rebuild_index'] = [
      '#type' => 'submit',
      '#value' => $this->t('Rebuild Index'),
      '#description' => $this->t('Reprocess all images in the Media Library to rebuild the search index.'),
      '#button_type' => 'danger',
      '#submit' => ['::rebuildIndex'],
    ];
    
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    // Validate that feature weights are reasonable.
    $color_weight = $form_state->getValue('default_color_weight');
    $edge_weight = $form_state->getValue('default_edge_weight');
    $phash_weight = $form_state->getValue('default_phash_weight');
    
    $total_weight = $color_weight + $edge_weight + $phash_weight;
    if ($total_weight == 0) {
      $form_state->setErrorByName('default_color_weight', $this->t('At least one feature weight must be greater than zero.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('reverse_image_search.settings')
      ->set('results_per_page', $form_state->getValue('results_per_page'))
      ->set('default_similarity_threshold', $form_state->getValue('default_similarity_threshold'))
      ->set('default_color_weight', $form_state->getValue('default_color_weight'))
      ->set('default_edge_weight', $form_state->getValue('default_edge_weight'))
      ->set('default_phash_weight', $form_state->getValue('default_phash_weight'))
      ->set('image_resize_dimensions', $form_state->getValue('image_resize_dimensions'))
      ->set('color_bins', $form_state->getValue('color_bins'))
      ->save();
    
    parent::submitForm($form, $form_state);
  }

  /**
   * Submit handler for rebuilding the index.
   */
  public function rebuildIndex(array &$form, FormStateInterface $form_state) {
    // Clear the existing index.
    $this->reverseImageSearchService->clearIndex();
    
    // Queue all media images for reindexing.
    $queue = $this->queueFactory->get('reverse_image_search_indexing');
    $queue->deleteQueue();
    $queue->createQueue();
    
    $media_storage = $this->entityTypeManager->getStorage('media');
    $query = $media_storage->getQuery()
      ->condition('bundle', ['image'], 'IN')
      ->accessCheck(FALSE);
    $media_ids = $query->execute();
    
    foreach ($media_ids as $media_id) {
      $queue->createItem(['mid' => $media_id]);
    }
    
    $this->messenger()->addStatus($this->t('Index rebuild has been initiated. @count media items have been queued for processing.', ['@count' => count($media_ids)]));
  }

  /**
   * Gets the total number of media image items.
   *
   * @return int
   *   The count of media image items.
   */
  protected function getTotalMediaImageCount() {
    $media_storage = $this->entityTypeManager->getStorage('media');
    $query = $media_storage->getQuery()
      ->condition('bundle', ['image'], 'IN')
      ->accessCheck(FALSE)
      ->count();
      
    return $query->execute();
  }
}
