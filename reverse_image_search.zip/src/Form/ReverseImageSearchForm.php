<?php

namespace Drupal\reverse_image_search\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Url;
use Drupal\file\Entity\File;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Core\Pager\PagerManagerInterface;
use Drupal\reverse_image_search\Service\ReverseImageSearchService;

/**
 * Form for the reverse image search.
 */
class ReverseImageSearchForm extends FormBase {

  /**
   * The file system service.
   *
   * @var \Drupal\Core\File\FileSystemInterface
   */
  protected $fileSystem;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The messenger.
   *
   * @var \Drupal\Core\Messenger\MessengerInterface
   */
  protected $messenger;

  /**
   * The pager manager.
   *
   * @var \Drupal\Core\Pager\PagerManagerInterface
   */
  protected $pagerManager;

  /**
   * The reverse image search service.
   *
   * @var \Drupal\reverse_image_search\Service\ReverseImageSearchService
   */
  protected $reverseImageSearchService;

  /**
   * Constructs a new ReverseImageSearchForm.
   *
   * @param \Drupal\Core\File\FileSystemInterface $file_system
   *   The file system service.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Messenger\MessengerInterface $messenger
   *   The messenger.
   * @param \Drupal\Core\Pager\PagerManagerInterface $pager_manager
   *   The pager manager.
   * @param \Drupal\reverse_image_search\Service\ReverseImageSearchService $reverse_image_search_service
   *   The reverse image search service.
   */
  public function __construct(
    FileSystemInterface $file_system,
    EntityTypeManagerInterface $entity_type_manager,
    MessengerInterface $messenger,
    PagerManagerInterface $pager_manager,
    ReverseImageSearchService $reverse_image_search_service
  ) {
    $this->fileSystem = $file_system;
    $this->entityTypeManager = $entity_type_manager;
    $this->messenger = $messenger;
    $this->pagerManager = $pager_manager;
    $this->reverseImageSearchService = $reverse_image_search_service;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('file_system'),
      $container->get('entity_type.manager'),
      $container->get('messenger'),
      $container->get('pager.manager'),
      $container->get('reverse_image_search.service')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'reverse_image_search_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['#attributes'] = ['enctype' => 'multipart/form-data'];
    
    $form['info'] = [
      '#type' => 'markup',
      '#markup' => '<p>' . $this->t('Upload an image to find similar images in your Media Library.') . '</p>',
    ];

    $form['image_upload'] = [
      '#type' => 'managed_file',
      '#title' => $this->t('Upload Image'),
      '#description' => $this->t('Upload an image to search for similar images. Allowed extensions: jpg, jpeg, png, gif, webp'),
      '#upload_location' => 'temporary://reverse_image_search/',
      '#upload_validators' => [
        'file_validate_extensions' => ['jpg jpeg png gif webp'],
        'file_validate_is_image' => [],
      ],
      '#required' => TRUE,
    ];
    
    $config = $this->config('reverse_image_search.settings');
    
    $form['search_options'] = [
      '#type' => 'details',
      '#title' => $this->t('Search Options'),
      '#open' => TRUE,
    ];
    
    $form['search_options']['similarity_threshold'] = [
      '#type' => 'range',
      '#title' => $this->t('Similarity Threshold'),
      '#description' => $this->t('Minimum similarity score (0-100) for results.'),
      '#min' => 0,
      '#max' => 100,
      '#default_value' => $form_state->getValue('similarity_threshold', $config->get('default_similarity_threshold') ?? 60),
    ];
    
    $form['search_options']['feature_weights'] = [
      '#type' => 'details',
      '#title' => $this->t('Feature Weights'),
      '#description' => $this->t('Adjust the importance of different image features for comparison.'),
      '#open' => FALSE,
    ];
    
    $form['search_options']['feature_weights']['color_weight'] = [
      '#type' => 'range',
      '#title' => $this->t('Color Importance'),
      '#description' => $this->t('Weight given to color features.'),
      '#min' => 0,
      '#max' => 100,
      '#default_value' => $form_state->getValue('color_weight', $config->get('default_color_weight') ?? 40),
    ];
    
    $form['search_options']['feature_weights']['edge_weight'] = [
      '#type' => 'range',
      '#title' => $this->t('Edge/Shape Importance'),
      '#description' => $this->t('Weight given to edge/shape features.'),
      '#min' => 0,
      '#max' => 100,
      '#default_value' => $form_state->getValue('edge_weight', $config->get('default_edge_weight') ?? 30),
    ];
    
    $form['search_options']['feature_weights']['phash_weight'] = [
      '#type' => 'range',
      '#title' => $this->t('Perceptual Hash Importance'),
      '#description' => $this->t('Weight given to perceptual hash comparison.'),
      '#min' => 0,
      '#max' => 100,
      '#default_value' => $form_state->getValue('phash_weight', $config->get('default_phash_weight') ?? 30),
    ];
    
    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Search'),
      '#button_type' => 'primary',
    ];
    
    // Display search results if available
    $results = $form_state->get('search_results');
    if (!empty($results)) {
      $query_image = NULL;
      if ($form_state->getValue('image_upload')) {
        $file = File::load($form_state->getValue('image_upload')[0]);
        if ($file) {
          $query_image = [
            'path' => $file->createFileUrl(),
            'alt' => $this->t('Query image'),
          ];
        }
      }
      
      $form['results'] = [
        '#theme' => 'reverse_image_search_results',
        '#results' => $results,
        '#query_image' => $query_image,
        '#pager' => [
          '#type' => 'pager',
        ],
        '#cache' => [
          'max-age' => 0,
        ],
      ];
    }
    
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    // Validate image upload.
    $image_upload = $form_state->getValue('image_upload');
    if (empty($image_upload)) {
      $form_state->setErrorByName('image_upload', $this->t('You must upload an image.'));
      return;
    }
    
    // Ensure uploaded file is accessible.
    $file = File::load($image_upload[0]);
    if (!$file) {
      $form_state->setErrorByName('image_upload', $this->t('The uploaded file could not be loaded.'));
      return;
    }
    
    // Validate file is an image.
    $mime_type = $file->getMimeType();
    $allowed_mime_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($mime_type, $allowed_mime_types)) {
      $form_state->setErrorByName('image_upload', $this->t('The uploaded file must be an image (JPEG, PNG, GIF, or WebP).'));
    }
    
    // Validate feature weights sum to 100%.
    $color_weight = $form_state->getValue('color_weight');
    $edge_weight = $form_state->getValue('edge_weight');
    $phash_weight = $form_state->getValue('phash_weight');
    
    $total_weight = $color_weight + $edge_weight + $phash_weight;
    if ($total_weight == 0) {
      $form_state->setErrorByName('feature_weights', $this->t('At least one feature weight must be greater than zero.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $image_upload = $form_state->getValue('image_upload');
    $file = File::load($image_upload[0]);
    
    if ($file) {
      $similarity_threshold = $form_state->getValue('similarity_threshold');
      $weights = [
        'color' => $form_state->getValue('color_weight'),
        'edge' => $form_state->getValue('edge_weight'),
        'phash' => $form_state->getValue('phash_weight'),
      ];
      
      // Normalize weights to sum to 1.0
      $total_weight = array_sum($weights);
      if ($total_weight > 0) {
        foreach ($weights as &$weight) {
          $weight = $weight / $total_weight;
        }
      } else {
        // If all weights are zero, use equal weights.
        $weights = [
          'color' => 0.33,
          'edge' => 0.33,
          'phash' => 0.34,
        ];
      }
      
      try {
        // Get the file URI
        $file_uri = $file->getFileUri();
        
        // Set limit and page for pagination
        $config = $this->config('reverse_image_search.settings');
        $limit = $config->get('results_per_page') ?? 20;
        $page = $this->pagerManager->getPager()->getCurrentPage() ?? 0;
        
        // Process search using the service
        $results = $this->reverseImageSearchService->searchSimilarImages(
          $file_uri,
          $similarity_threshold / 100, // Convert to 0-1 scale
          $weights,
          $limit,
          $page * $limit
        );
        
        // Store results for display
        $form_state->set('search_results', $results);
        $form_state->setRebuild(TRUE);
        
        // Provide feedback on number of results
        if (empty($results)) {
          $this->messenger->addStatus($this->t('No similar images found in the Media Library.'));
        }
        else {
          $this->messenger->addStatus($this->t('Found @count similar images in the Media Library.', ['@count' => count($results)]));
        }
      }
      catch (\Exception $e) {
        $this->messenger->addError($this->t('Error processing image search: @error', ['@error' => $e->getMessage()]));
        $this->logger('reverse_image_search')->error('Error processing reverse image search: @error', ['@error' => $e->getMessage()]);
      }
    }
  }
}
